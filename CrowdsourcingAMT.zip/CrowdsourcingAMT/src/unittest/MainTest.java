package unittest;

import lib.LogNormalGenerator;

public class MainTest {

	public void test() {
		LogNormalGenerator lognormal = new LogNormalGenerator(10, 9);
		System.out.println(lognormal.nextDouble());
	}

}
