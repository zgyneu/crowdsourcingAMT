package crowdsourcing;

import java.awt.Color;

import repast.simphony.visualizationOGL2D.DefaultStyleOGL2D;


public class AgentStyle extends DefaultStyleOGL2D {

	@Override
	public Color getColor(Object agent) {
		
			return ((DisplayColor)agent).getColor();

	}
	

}
