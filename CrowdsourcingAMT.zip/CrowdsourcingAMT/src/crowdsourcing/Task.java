package crowdsourcing;

import java.util.Iterator;
import java.util.Vector;

import repast.simphony.context.Context;
import repast.simphony.engine.environment.RunEnvironment;
import repast.simphony.engine.schedule.ScheduleParameters;
import repast.simphony.engine.schedule.ScheduledMethod;
import repast.simphony.space.graph.Network;
import repast.simphony.space.graph.RepastEdge;

public class Task {

	public Task(Context<Object> context, Network<Object> network, int requiredTime, int postTime, double[] params)
	{
		m_context = context;
		m_network = network;
		m_requiredTime = requiredTime;
		m_postTime = postTime;
		
		m_id = s_id++;
		
		assignTaskParams(params);
	}
	
	@ScheduledMethod(start = 1, interval = 1, priority=ScheduleParameters.LAST_PRIORITY)
	public void step() {
		double currentTick = RunEnvironment.getInstance().getCurrentSchedule().getTickCount();
		if (m_worker.size() > 0 && currentTick - m_startTime >= m_requiredTime)
		{
			m_endTime = (int)currentTick;
			Iterator<RepastEdge<Object>> iter = m_network.getEdges(this).iterator();
			while (iter.hasNext())
				m_network.removeEdge(iter.next());
			m_context.remove(this);
			
			for (Agent worker : m_worker)
				worker.removeTask(this);
		}
	}
	
	private void assignTaskParams(double[] params)
	{
		incentive = params[EnvironmentalVars.Incentive];
		videoSpeed = (int)params[EnvironmentalVars.VideoSpeed];
		videoDuration = (int)params[EnvironmentalVars.VideoDuration];
		weekday = (int)params[EnvironmentalVars.Weekday];
		country = (int)params[EnvironmentalVars.Country];
		approvalRate = (int)params[EnvironmentalVars.ApprovalRate];
		timeofday = (int)params[EnvironmentalVars.TimeOfDay];
		hitLifetime = (int)params[EnvironmentalVars.Lifetime];
		assignmentDuration = (int)params[EnvironmentalVars.AssignmentDuration];
	}
	
	public int getRequiredTime()
	{
		return m_requiredTime;
	}
	
	public void setRequiredTime(int arg)
	{
		m_requiredTime = arg;
	}
	
	public int getPostTime()
	{
		return m_postTime;
	}
	
	
	public int get_startTime() {
		return m_startTime;
	}

	public void set_startTime(int startTime) {
		this.m_startTime = startTime;
	}

	public int get_endTime() {
		return m_endTime;
	}

	public void set_endTime(int endTime) {
		this.m_endTime = endTime;
	}
	
	public long getID()
	{
		return m_id;
	}
	
	public void setWorker(Agent agent)
	{
		m_worker.add(agent);
	}
	
	public static void resetID()
	{
		s_id = 0;
	}
	
	

	public double getIncentive() {
		return incentive;
	}

	public void setIncentive(double incentive) {
		this.incentive = incentive;
	}

	public int getVideoSpeed() {
		return videoSpeed;
	}

	public void setVideoSpeed(int videoSpeed) {
		this.videoSpeed = videoSpeed;
	}

	public int getVideoDuration() {
		return videoDuration;
	}

	public void setVideoDuration(int videoDuration) {
		this.videoDuration = videoDuration;
	}

	public int getWeekday() {
		return weekday;
	}

	public void setWeekday(int weekday) {
		this.weekday = weekday;
	}

	public int getCountry() {
		return country;
	}

	public void setCountry(int country) {
		this.country = country;
	}

	public int getApprovalRate() {
		return approvalRate;
	}

	public void setApprovalRate(int approvalRate) {
		this.approvalRate = approvalRate;
	}

	public int getTimeofday() {
		return timeofday;
	}

	public void setTimeofday(int timeofday) {
		this.timeofday = timeofday;
	}

	public int getHitLifetime() {
		return hitLifetime;
	}

	public void setHitLifetime(int hitLifetime) {
		this.hitLifetime = hitLifetime;
	}

	public int getAssignmentDuration() {
		return assignmentDuration;
	}

	public void setAssignmentDuration(int assignmentDuration) {
		this.assignmentDuration = assignmentDuration;
	}
	
	public void setAccuracy(double accuracy)
	{
		this.m_accuracy = accuracy;
	}
	
	public double getAccuracy()
	{
		return m_accuracy > 1 ? 1 : (m_accuracy < 0 ? 0 : m_accuracy);
	}

	private int m_requiredTime = 0;
	private int m_postTime = 0;
	private int m_startTime = 0;
	private int m_endTime = Integer.MAX_VALUE;
	private double m_accuracy = 0;
	private long m_id = 0;
	private Vector<Agent> m_worker = new Vector<Agent>();
	private Context<Object> m_context = null;
	private Network<Object> m_network = null;
	
	private double incentive = 0;
	private int videoSpeed = 0;
	private int videoDuration = 0;
	private int weekday = 0;
	private int country = 0;
	private int approvalRate = 0;
	private int timeofday = 0;
	private int hitLifetime = 0;
	private int assignmentDuration = 0;
	
	private static long s_id = 0;
}
