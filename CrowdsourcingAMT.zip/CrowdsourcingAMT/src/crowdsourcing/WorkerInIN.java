package crowdsourcing;

import repast.simphony.context.Context;
import repast.simphony.space.graph.Network;

public class WorkerInIN extends Agent {

	public WorkerInIN(Context<Object> context, Network<Object> network)
	{
		super(context, network);
	}

	@Override
	protected String getCountry() {
		return "IN";
	}
	
	@Override
	protected int getWorkingTime() {
		return (int)m_workingTime.nextDouble();
	}
	
	@Override
	protected int getNumTasksToTake()
	{
		return 0;
	}

	@Override
	protected double getShowupChance() {
		return 0;
	}
	
	
}
