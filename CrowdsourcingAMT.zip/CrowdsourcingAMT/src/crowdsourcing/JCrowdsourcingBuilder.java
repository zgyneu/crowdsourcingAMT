package crowdsourcing;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.TreeMap;
import java.util.Vector;

import analytics.Analytics;
import analytics.Pair;
import analytics.RunHelper;
import cern.jet.random.Exponential;
import cern.jet.random.Normal;
import data.DataStore;
import repast.simphony.context.Context;
import repast.simphony.context.space.graph.NetworkBuilder;
import repast.simphony.context.space.grid.GridFactory;
import repast.simphony.context.space.grid.GridFactoryFinder;
import repast.simphony.dataLoader.ContextBuilder;
import repast.simphony.engine.environment.RunEnvironment;
import repast.simphony.engine.environment.RunState;
import repast.simphony.engine.schedule.ISchedule;
import repast.simphony.engine.schedule.ScheduleParameters;
import repast.simphony.engine.schedule.ScheduledMethod;
import repast.simphony.parameter.Parameters;
import repast.simphony.random.RandomHelper;
import repast.simphony.space.graph.Network;
import repast.simphony.space.grid.Grid;
import repast.simphony.space.grid.GridBuilderParameters;
import repast.simphony.space.grid.SimpleGridAdder;
import repast.simphony.space.grid.WrapAroundBorders;
import repast.simphony.util.collections.IndexedIterable;



public class JCrowdsourcingBuilder implements ContextBuilder<Object> {

	@Override
	public Context build(Context<Object> context) {
		context.setId("crowdsourcing");

		Parameters params = RunEnvironment.getInstance().getParameters();
		int width = (Integer)params.getValue("grid_width");
		int height = (Integer)params.getValue("grid_height");
		int numAgentsUS = (Integer)params.getValue("num_agents_us");
		int numAgentsPH = (Integer)params.getValue("num_agents_ph");
		int numAgentsIN = (Integer)params.getValue("num_agents_in");
		int numAgentsOther = (Integer)params.getValue("num_agents_other");
		int numCustomers = (Integer)params.getValue("num_requestors");
		
		NetworkBuilder<Object> netBuilder = new NetworkBuilder<Object>(
				"servie_network", context, true);
		netBuilder.buildNetwork();
		
		GridFactory gridFactory = GridFactoryFinder.createGridFactory(null);
		Grid<Object> grid = gridFactory.createGrid("grid_customer", context,
				new GridBuilderParameters<Object>(new WrapAroundBorders(),
						new SimpleGridAdder<Object>(), true, width, height));
	
		Network<Object> net = (Network<Object>)context.getProjection("servie_network");

		int agentPos = 0;
		for (int i = 0; i < numAgentsUS; ++i,++agentPos)
		{
			Agent agent = new WorkerInUS(context, net);
			context.add(agent);
			grid.moveTo(agent, width-1-agentPos/height, agentPos);			
		}
		for (int i = 0; i < numAgentsPH; ++i,++agentPos)
		{
			Agent agent = new WorkerInPH(context, net);
			context.add(agent);
			grid.moveTo(agent, width-1-agentPos/height, agentPos);			
		}
		for (int i = 0; i < numAgentsIN; ++i,++agentPos)
		{
			Agent agent = new WorkerInIN(context, net);
			context.add(agent);
			grid.moveTo(agent, width-1-agentPos/height, agentPos);
			
		}
		for (int i = 0; i < numAgentsOther; ++i,++agentPos)
		{
			Agent agent = new WorkerInOther(context, net);
			context.add(agent);
			grid.moveTo(agent, width-1-agentPos/height, agentPos);			
		}
		
		for (int i = 0; i < numCustomers; ++i)
		{			
			Requestor requestor = new Requestor(context, net, grid);
			context.add(requestor);
			grid.moveTo(requestor, i/height,i);
		}
	
		ISchedule schedule = RunEnvironment.getInstance().getCurrentSchedule();
		ScheduleParameters param = ScheduleParameters.createRepeating(1, 1, ScheduleParameters.LAST_PRIORITY);
		schedule.schedule(param, this, "globalMethod");
		param = ScheduleParameters.createRepeating(1, 1, ScheduleParameters.FIRST_PRIORITY);
		schedule.schedule(param, this, "init");	
		param = ScheduleParameters.createRepeating(1, 1);
		schedule.schedule(param, this, "activateAgents");
		
		m_availabilityDist = country_hour_available();
		
		clearStateVars();
		for (String country : m_availabilityDist.keySet())
			DataStore.getInstance().g_availability.put(country, 0);

		return context;
	}
	
	public void init()
	{
		int currentTick = (int)RunEnvironment.getInstance().getCurrentSchedule().getTickCount();
		int callFrequency = (Integer) RunEnvironment.getInstance()
				.getParameters().getValue("callFrequecy");
		int currentHour = ((currentTick-1) / callFrequency) % 24;
		
		if ((currentTick-1) % callFrequency != 0)
			return;
		
		for (Map.Entry<String, Integer> entry : DataStore.getInstance().g_availability.entrySet())
		{
			int availableNum = m_availabilityDist.get(entry.getKey()).get(currentHour).nextInt();
			availableNum = availableNum < 0 ? 0 : availableNum;
			entry.setValue(availableNum);
		}
	}
	
	public void globalMethod()
	{
		//System.out.println(RunEnvironment.getInstance().getCurrentSchedule().getTickCount());
		if (RunEnvironment.getInstance().getCurrentSchedule().getTickCount() == 
				(Integer)RunEnvironment.getInstance().getParameters().getValue("stopTime"))
		{		
			int numPerDay = 0;
			double sumTime = 0;
			
			TreeMap<String, Vector<Integer>> showup = new TreeMap<String, Vector<Integer>>();
			for (Map.Entry<Integer, HashMap<Agent,Integer>> entry : DataStore.getInstance().g_showupPerDay.entrySet() )
			{
				for (Map.Entry<Agent,Integer> entry2 : entry.getValue().entrySet())
				{
					String country = entry2.getKey().getCountry();
					Vector<Integer> times = showup.get(country);
					if (times == null)
					{
						times = new Vector<Integer>();
						showup.put(country, times);
					}
					times.add(entry2.getValue());
				}
			}
			
//			for (Map.Entry<String, Vector<Integer>> entry : showup.entrySet())
//			{
//				System.out.println(entry.getKey());
//				for (Integer time : entry.getValue())
//					System.out.println(time);
//			}
			
//			Vector<Task> metrics = DataStore.getInstance().g_tasks;
//			double sum = 0;
//			int num = 0;
//			int num_task = (Integer)RunEnvironment.getInstance().getParameters().getValue("num_tasks");
//			for (int i = 0; i < metrics.size(); ++i)
//			{
//				if (metrics.get(i).get_endTime() != Integer.MAX_VALUE)
//				{
//					sum += metrics.get(i).get_endTime() - metrics.get(i).get_startTime();
//					++num;					
//				}
//				
//				if ((i+1)%(num_task*24) == 0)
//				{
//					System.out.print(sum/num+" ");
//					sum = 0;
//					num = 0;
//				}
//			}
			
			RunEnvironment.getInstance().endRun();
		}
	}
	
	public void activateAgents() {
		ArrayList<Agent> agentList = new ArrayList<Agent>();
		
		Iterator<Agent> iter = RunState.getInstance().getMasterContext().getObjects(Agent.class).iterator();
		while (iter.hasNext())
		{
			agentList.add(iter.next());
		}
		
		Collections.shuffle(agentList);

//		int currentTick = (int)RunEnvironment.getInstance().getCurrentSchedule().getTickCount();
//		final HashMap<Agent,Integer> agent_tasks = g_numberOfTasksPerWorker.get((currentTick-1)/(60*24));
//		final double showupCoefficient = (Double)RunEnvironment.getInstance().getParameters().getValue("showupPowerLawCoefficient");
//		Collections.sort(agentList, new Comparator<Agent>() {
//
//			@Override
//			public int compare(Agent o1, Agent o2) {
//				Integer tasks1 = null;
//				Integer tasks2 = null;
//				if (agent_tasks == null)
//				{
//					tasks1 = RandomHelper.nextInt();
//					tasks2 = RandomHelper.nextInt();
//				}
//				else
//				{
//					tasks1 = agent_tasks.get(o1);
//					tasks2 = agent_tasks.get(o2);
//				}
//				tasks1 = tasks1 == null ? 0 : tasks1;
//				tasks2 = tasks2 == null ? 0 : tasks2;
//				
//				if (Math.max(tasks1, tasks2) == 0)
//					return RandomHelper.nextIntFromTo(-1, 1);
//				
//				double rand = RandomHelper.nextDoubleFromTo(0, 1);
//				double prop = Math.abs(tasks1-tasks2)/Math.max(tasks1, tasks2)*showupCoefficient;
//				int sign = tasks1 > tasks2 ? 1 : -1;
//				return rand < prop ? -1*sign : rand == prop ? 0 : sign;
//				//return tasks1 < tasks2 ? 1 : tasks1 == tasks2 ? 0 : -1;
//			}
//			
//		});

		for (final Agent agent : agentList) {
			agent.step();
		}
	}
	
	private TreeMap<String, TreeMap<Integer, Normal>> country_hour_available()
	{
		TreeMap<String, TreeMap<Integer, Pair<Double,Double>>> country_hour_available = new Analytics().country_hour_available();
		TreeMap<String, TreeMap<Integer, Normal>> country_hour_normal = new TreeMap<String, TreeMap<Integer, Normal>>();
		for (Map.Entry<String, TreeMap<Integer, Pair<Double,Double>>> entry : country_hour_available.entrySet())
		{
			TreeMap<Integer, Normal> hour_normal = new TreeMap<Integer, Normal>();
			country_hour_normal.put(entry.getKey(), hour_normal);
			for (Map.Entry<Integer, Pair<Double,Double>> entry2 : entry.getValue().entrySet())
			{
				Pair<Double, Double> mean_stdev = entry2.getValue();
				Normal normalDist = RandomHelper.createNormal(mean_stdev.getVar1(), mean_stdev.getVar2());
				hour_normal.put(entry2.getKey(), normalDist);
			}
		}
		
		return country_hour_normal;
	}
	
	private void clearStateVars()
	{
		DataStore.getInstance().clearAll();
		Task.resetID();
		Agent.resetID();
	}
	
	
	private TreeMap<String, TreeMap<Integer, Normal>> m_availabilityDist;

	public static int g_timeIntervalToAnalyze = 7;
}
