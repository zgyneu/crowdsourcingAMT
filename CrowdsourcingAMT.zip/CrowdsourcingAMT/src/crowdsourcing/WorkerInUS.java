package crowdsourcing;

import cern.jet.random.Beta;
import cern.jet.random.Exponential;
import repast.simphony.context.Context;
import repast.simphony.engine.environment.RunEnvironment;
import repast.simphony.space.graph.Network;

public class WorkerInUS extends Agent {

	public WorkerInUS(Context<Object> context, Network<Object> network)
	{
		super(context, network);
	}

	@Override
	protected String getCountry() {
		return "US";
	}
	
	@Override
	protected int getWorkingTime() {
		return (int)m_workingTime.nextDouble();
	}
	
	@Override
	protected int getNumTasksToTake()
	{
		return 0;
	}

	@Override
	protected double getShowupChance() {
		return 0;
	}
}
