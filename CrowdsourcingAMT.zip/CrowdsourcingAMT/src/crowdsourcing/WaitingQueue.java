package crowdsourcing;

import java.util.LinkedList;

public class WaitingQueue<Type>{
	
	private LinkedList<Type> m_queue = new LinkedList<Type>();
	private static WaitingQueue m_instance = null;
	
	private WaitingQueue()
	{		
	}
	
	public static WaitingQueue getInstance()
	{
		if (m_instance == null)
			m_instance = new WaitingQueue();
		return m_instance;
	}
	
	public synchronized void push(Type c)
	{
		m_queue.add(c);
	}
	
	public synchronized Type pop()
	{
		if (m_queue.isEmpty())
			return null;
		return m_queue.pop();
	}
	
	public synchronized int size()
	{
		return m_queue.size();
	}

}
