package crowdsourcing;

import java.awt.Color;
import java.util.Vector;

import lib.LogNormalGenerator;
import lib.UniformLinearRegressionGenerator;
import cern.jet.random.Beta;
import cern.jet.random.Exponential;
import data.DataStore;
import repast.simphony.context.Context;
import repast.simphony.engine.environment.RunEnvironment;
import repast.simphony.space.graph.Network;

public abstract class Agent implements DisplayColor{
	
	private Context<Object> m_context = null;
	private Network<Object> m_network = null;
	protected LogNormalGenerator m_workingTime = null;
	protected LogNormalGenerator m_acceptanceTime = null;
	protected LogNormalGenerator m_accuracy = null;
	protected UniformLinearRegressionGenerator m_acceptanceRate = null;
	private Vector<Task> m_task = new Vector<Task>();
	
	private long m_id = 0;
	private static long s_id = 0;
	
	public Agent(Context<Object> context, Network<Object> network)
	{
		m_context = context;
		m_network = network;
		m_id = s_id++;
	}

	//@ScheduledMethod(start = 1, interval = 1)
	public void step() {
//		if (!checkAvailability())
//			return;
		
		doHIT();
	}
	
	private double computeMuSigma(Task task, String paramName, int index)
	{
		String paras = (String)RunEnvironment.getInstance().getParameters().getValue(paramName);		
		String[] paramPairs = paras.split(";");
		double mu = splitTwoParams(paramPairs[EnvironmentalVars.Const])[index]
				+ task.getIncentive()
				* splitTwoParams(paramPairs[EnvironmentalVars.Incentive])[index]
				+ task.getVideoSpeed()
				* splitTwoParams(paramPairs[EnvironmentalVars.VideoSpeed])[index]
				+ task.getVideoDuration()
				* splitTwoParams(paramPairs[EnvironmentalVars.VideoDuration])[index]
				+ task.getWeekday()
				* splitTwoParams(paramPairs[EnvironmentalVars.Weekday])[index]
				+ task.getCountry()
				* splitTwoParams(paramPairs[EnvironmentalVars.Country])[index]
				+ task.getApprovalRate()
				* splitTwoParams(paramPairs[EnvironmentalVars.ApprovalRate])[index]
				+ task.getTimeofday()
				* splitTwoParams(paramPairs[EnvironmentalVars.TimeOfDay])[index]
				+ task.getHitLifetime()
				* splitTwoParams(paramPairs[EnvironmentalVars.Lifetime])[index]
				+ task.getAssignmentDuration()
				* splitTwoParams(paramPairs[EnvironmentalVars.AssignmentDuration])[index];		
		return mu;
	}
	
	private LogNormalGenerator initRandomGenerator(Task task, String paramName)
	{
		double[] result = new double[2];
//		String paras = (String)RunEnvironment.getInstance().getParameters().getValue("workingTimeRegression");
//		String paras = (String)RunEnvironment.getInstance().getParameters().getValue(paramName);		
//		String[] paramPairs = paras.split(";");
//		double mu = splitTwoParams(paramPairs[EnvironmentalVars.Const])[0]
//				+ task.getIncentive()
//				* splitTwoParams(paramPairs[EnvironmentalVars.Incentive])[0]
//				+ task.getVideoSpeed()
//				* splitTwoParams(paramPairs[EnvironmentalVars.VideoSpeed])[0]
//				+ task.getVideoDuration()
//				* splitTwoParams(paramPairs[EnvironmentalVars.VideoDuration])[0]
//				+ task.getWeekday()
//				* splitTwoParams(paramPairs[EnvironmentalVars.Weekday])[0]
//				+ task.getCountry()
//				* splitTwoParams(paramPairs[EnvironmentalVars.Country])[0]
//				+ task.getApprovalRate()
//				* splitTwoParams(paramPairs[EnvironmentalVars.ApprovalRate])[0]
//				+ task.getTimeofday()
//				* splitTwoParams(paramPairs[EnvironmentalVars.TimeOfDay])[0]
//				+ task.getHitLifetime()
//				* splitTwoParams(paramPairs[EnvironmentalVars.Lifetime])[0]
//				+ task.getAssignmentDuration()
//				* splitTwoParams(paramPairs[EnvironmentalVars.AssignmentDuration])[0];
		double mu = computeMuSigma(task, paramName, 0);
		System.out.println(task + " " +mu);
		double sigma = computeMuSigma(task, paramName, 1);
//		double sigma = splitTwoParams(paramPairs[EnvironmentalVars.Const])[1]
//				+ task.getIncentive()
//				* splitTwoParams(paramPairs[EnvironmentalVars.Incentive])[1]
//				+ task.getVideoSpeed()
//				* splitTwoParams(paramPairs[EnvironmentalVars.VideoSpeed])[1]
//				+ task.getVideoDuration()
//				* splitTwoParams(paramPairs[EnvironmentalVars.VideoDuration])[1]
//				+ task.getWeekday()
//				* splitTwoParams(paramPairs[EnvironmentalVars.Weekday])[1]
//				+ task.getCountry()
//				* splitTwoParams(paramPairs[EnvironmentalVars.Country])[1]
//				+ task.getApprovalRate()
//				* splitTwoParams(paramPairs[EnvironmentalVars.ApprovalRate])[1]
//				+ task.getTimeofday()
//				* splitTwoParams(paramPairs[EnvironmentalVars.TimeOfDay])[1]
//				+ task.getHitLifetime()
//				* splitTwoParams(paramPairs[EnvironmentalVars.Lifetime])[1]
//				+ task.getAssignmentDuration()
//				* splitTwoParams(paramPairs[EnvironmentalVars.AssignmentDuration])[1];
		return new LogNormalGenerator(mu, sigma);
	}
	
	private double[] splitTwoParams(String pair)
	{
		double[] result = new double[2];
		String[] values = pair.split(",");
		result[0] = Double.parseDouble(values[0]);
		result[1] = values.length>1&&values[1]!=null&&values[1]!=""?Double.parseDouble(values[1]):Double.NaN;
		return result;
	}
	
	private boolean checkAvailability() {
		int callFrequency = (Integer) RunEnvironment.getInstance()
				.getParameters().getValue("callFrequecy");
		double currentTick = RunEnvironment.getInstance()
				.getCurrentSchedule().getTickCount();
		
		if ((currentTick-1) % callFrequency != 0)
			return false;
		
//		if (getShowupChance() < 5.3)
//			return false;
		
		int availableNum = DataStore.getInstance().g_availability.get(getCountry());
		if (availableNum <= 0)
			return false;
		
		DataStore.getInstance().g_availability.put(getCountry(), availableNum-1);
		
		// update g_numberOfWorkers
		DataStore.getInstance().updateNumberOfWorkers((int)currentTick, this);
		
		return true;
	}
	
	private void doHIT()
	{
		int currentTick = (int)RunEnvironment.getInstance().getCurrentSchedule().getTickCount();
//		if (m_task != null)
//		{
//			
//			if (++m_iStartTime >= m_task.getRequiredTime())
//			{
//				m_context.remove(m_task);
//				m_task.set_endTime(currentTick);
//				m_task = null;
//				m_color = Color.green;
//			}
//			return;
//		}
		
//		int numberOfTaskToTake = getNumTasksToTake();
		int numberOfTaskToTake = 1;
		int i = 0;
		for (; i < numberOfTaskToTake; ++i)
		{
			Task task = (Task)WaitingQueue.getInstance().pop();
			if (task == null)
				break;
			m_acceptanceRate = new UniformLinearRegressionGenerator(computeMuSigma(task, "acceptanceRegression", 0), 1);
			if (!m_acceptanceRate.isTrue())
				break;
	//		m_iStartTime = 0;
			m_task.add(task);
			m_acceptanceTime = initRandomGenerator(task, "acceptingTimeRegression");
			m_workingTime = initRandomGenerator(task, "workingTimeRegression");
			m_accuracy = initRandomGenerator(task, "accuracyRegression");
			int acceptingTime = (int)m_acceptanceTime.nextDouble()/60;
			int workingTime = (int)m_workingTime.nextDouble()/60;
			double accuracy = m_accuracy.nextDouble();
			task.set_startTime(currentTick+acceptingTime);
			task.setRequiredTime(workingTime);
//			task.setRequiredTime(getWorkingTime());
			task.setAccuracy(1-accuracy);
			task.setWorker(this);
			m_network.addEdge(task, this);
		}
		
		// update g_numberOfTasksPerWorker
		DataStore.getInstance().updateNumberOfTasksPerWorker(this, currentTick, i);
		DataStore.getInstance().updateShowupPerDay(this, currentTick);
	}
	
	public void removeTask(Task taskToRemove)
	{
		m_task.remove(taskToRemove);
	}
	
	public Vector<Task> getTasks()
	{
		return m_task;
	}
	
	protected abstract String getCountry();
	
	protected abstract int getWorkingTime();
	
	protected abstract int getNumTasksToTake();
	
	protected abstract double getShowupChance();
	
	public long getID()
	{
		return m_id;
	}
	
	public static void resetID()
	{
		s_id = 0;
	}
	
	public Color getColor()
	{
		if (m_network.getEdges(this).iterator().hasNext())
			return Color.red;
		else
			return Color.green;
	}
}
