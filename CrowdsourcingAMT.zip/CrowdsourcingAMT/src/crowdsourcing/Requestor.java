package crowdsourcing;

import java.awt.Color;

import cern.jet.random.Exponential;
import cern.jet.random.Poisson;
import data.DataStore;
import repast.simphony.context.Context;
import repast.simphony.engine.environment.RunEnvironment;
import repast.simphony.engine.schedule.ScheduleParameters;
import repast.simphony.engine.schedule.ScheduledMethod;
import repast.simphony.random.RandomHelper;
import repast.simphony.space.graph.Network;
import repast.simphony.space.grid.Grid;
import repast.simphony.space.grid.GridPoint;

public class Requestor implements DisplayColor
{
	private Color m_color = Color.blue;
	private Network<Object> m_network = null;
	private Context<Object> m_context = null;
	private Grid<Object> m_grid = null;
	private Poisson m_poisson = null;
	private Exponential m_exponential = null;
	private double m_iStartTime = -1;
	private int m_iInterval = 0;
	private int m_callFrequency = 0;

	public Requestor(Context<Object> context, Network<Object> network, Grid<Object> grid)
	{
		m_network = network;
		m_context = context;
		m_grid = grid;
		m_callFrequency = (Integer) RunEnvironment.getInstance()
				.getParameters().getValue("callFrequecy");
		m_poisson = RandomHelper.createPoisson(m_callFrequency);
		int requiredTime = (Integer)RunEnvironment.getInstance().getParameters().getValue("requiredTime");
		m_exponential = RandomHelper.createExponential(1.0/requiredTime);
	}

	@ScheduledMethod(start = 1, interval = 1, priority=ScheduleParameters.FIRST_PRIORITY)
	public void step()
	{
		postTasks();
	}
	
	private void postTasks()
	{
		int callFrequency = (Integer) RunEnvironment.getInstance()
				.getParameters().getValue("callFrequecy");
		double currentTick = RunEnvironment.getInstance()
				.getCurrentSchedule().getTickCount();
		int numTasks = (Integer)RunEnvironment.getInstance()
				.getParameters().getValue("num_tasks");
		int requiredTime = (Integer)RunEnvironment.getInstance()
				.getParameters().getValue("requiredTime");
		
		if ((currentTick-1) % callFrequency != 0)
			return;
		
		for (int i = 0; i < numTasks; ++i)
		{
			double[] taskParams = obtainTaskParams((int)(currentTick-1) / callFrequency);
			if (taskParams == null)
				continue;
			Task task = new Task(m_context, m_network, m_exponential.nextInt(), (int)currentTick, taskParams);
			
			GridPoint gp = findEmptySpace();
			if (gp != null)
			{
				m_context.add(task);
				m_grid.moveTo(task, gp.getX(),gp.getY());
				
				WaitingQueue.getInstance().push(task);
				DataStore.getInstance().g_tasks.add(task);
				
				m_network.addEdge(this, task);
			}
			//grid.moveTo(task, RandomHelper.nextIntFromTo(2*width/5, 3*width/5-1), RandomHelper.nextIntFromTo(0, height-1));

		}
	}
	
	private double[] obtainTaskParams(int index)
	{
		double[] result = null;
		String paras = (String)RunEnvironment.getInstance().getParameters().getValue("taskParams");
		String[] paramPairs = paras.split(";");
		if (index >= paramPairs.length)
			return result;
		String[] params = paramPairs[index].split(",");
		result = new double[params.length];
		for (int i = 0; i < result.length; ++i)
			result[i] = Double.parseDouble(params[i]);
		return result;
	}
	
	private GridPoint findEmptySpace()
	{
		int start = 20;
		int end = 60;
		for (int i = start; i <= end; ++i)
		{
			for (int j = 0; j < m_grid.getDimensions().getHeight(); ++j)
			{
				if (m_grid.getObjectAt(i, j) == null)
				{
					return new GridPoint(i,j);
				}
			}
		}
		return null;
	}
	
	private void makeCall()
	{
		if (!m_network.getEdges(this).iterator().hasNext())
		{
			m_color = Color.blue;
			double currentTick = RunEnvironment.getInstance()
					.getCurrentSchedule().getTickCount();

			if (m_iStartTime == -1)
			{
				m_iStartTime = currentTick;
				m_iInterval = m_poisson.nextInt();
			}

			if ((int) (currentTick - m_iStartTime) == m_iInterval)
			{
				WaitingQueue.getInstance().push(this);
				m_color = Color.red;
			}
		}
		else
		{
			m_iStartTime = -1;
		}
	}
	
	public Color getColor()
	{
		return m_color;
	}
}
