package crowdsourcing;

import repast.simphony.context.DefaultContext;
import repast.simphony.context.space.grid.GridFactory;
import repast.simphony.context.space.grid.GridFactoryFinder;
import repast.simphony.space.grid.Grid;
import repast.simphony.space.grid.GridBuilderParameters;
import repast.simphony.space.grid.SimpleGridAdder;
import repast.simphony.space.grid.WrapAroundBorders;

public class SubGrid extends DefaultContext<Object> {

	private String name = "";
	private Grid<Object> grid = null;
	public SubGrid(String gridName)
	{
		super("context_"+gridName);
		this.setId("context_"+gridName);
		name = gridName;
		GridFactory gridFactory = GridFactoryFinder.createGridFactory(null);
		grid = gridFactory.createGrid("grid_"+gridName, this,
				new GridBuilderParameters<Object>(new WrapAroundBorders(),
						new SimpleGridAdder<Object>(), true, 50, 50));
	}
	
	public String getName()
	{
		return name;
	}
	
	public Grid<Object> getGrid()
	{
		return grid;
	}
}
