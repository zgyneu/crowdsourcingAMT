package crowdsourcing;

import java.awt.Color;

public interface DisplayColor
{
	public Color getColor();
}
