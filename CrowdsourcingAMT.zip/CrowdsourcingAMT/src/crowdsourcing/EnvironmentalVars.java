package crowdsourcing;

public class EnvironmentalVars {
	private static int index = 0;
	public static int Incentive = index++;
	public static int VideoSpeed = index++;
	public static int VideoDuration = index++;
	public static int Weekday = index++;
	public static int Country = index++;
	public static int ApprovalRate = index++;
	public static int TimeOfDay = index++;
	public static int Lifetime = index++;
	public static int AssignmentDuration = index++;
	public static int Const = index++;
}
