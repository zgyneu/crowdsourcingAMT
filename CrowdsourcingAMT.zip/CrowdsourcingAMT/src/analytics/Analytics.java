package analytics;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Comparator;
import java.util.Date;
import java.util.Iterator;
import java.util.Map;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.Vector;

import lib.FileHelper;
import lib.StringHelper;

public class Analytics
{

	public static void main(String[] args)
	{
		new Analytics().compareBatchResults();
	}
	
	private void compareBatchResults()
	{
		String metricName = "AcceptingTime";
		Vector<String> realdataFile = FileHelper.readFile("realdata.txt");
		Vector<Vector<String>> realdata = new Vector<Vector<String>>();
		for (int i = 0; i < 30; ++i)
		{
			Vector<String> row = new Vector<String>();
			for (String line : realdataFile)
			{
				String[] values = line.split("	");
				if (i < values.length)
					row.add(values[i]);
				else
					row.add("	");
			}
			realdata.add(row);
		}
		
		Vector<String> simulateddataFile = FileHelper.readFile("simulateddata.txt");
		Vector<Vector<String>> simulateddata = new Vector<Vector<String>>();
		for (String line : simulateddataFile)
		{
//			Vector<String> values = StringHelper.parseRegExAllOccurrences(line, "AcceptingTime: ([0-9.0-9]*)");
//			Vector<String> values = StringHelper.parseRegExAllOccurrences(line, "WorkingTime: ([0-9.0-9]*)");
			Vector<String> values = StringHelper.parseRegExAllOccurrences(line, metricName+": ([0-9.0-9]*)");
			simulateddata.add(values);
		}
		
		for (int i = 0; i < simulateddata.size(); ++i)
		{
			for (int j = 0; j < simulateddata.get(i).size(); ++j)
			{
				if (j < realdata.get(i).size() && !realdata.get(i).get(j).equals("	"))
				{
					if (metricName.equals("Accuracy"))
						System.out.print(simulateddata.get(i).get(j)+ "," +Double.parseDouble(realdata.get(i).get(j))+",");
					else
						System.out.print(simulateddata.get(i).get(j)+ "," +Double.parseDouble(realdata.get(i).get(j))/60+",");
				}
				else
					System.out.print(simulateddata.get(i).get(j)+ "," +" "+",");
			}
			System.out.println();
		}
	}
	
	private void analyzeTaskCompletionWeekday()
	{
		Vector<String> contents = readInputFile("batchCompletionRateDataI.data");
		TreeMap<Integer, TreeMap<Integer, Vector<Double>>> weekday_hour_numberMap = new TreeMap<Integer, TreeMap<Integer, Vector<Double>>>();
		for (int i = 1; i < contents.size(); ++i)
		{
			String s = contents.get(i);
			String[] fields = s.split("	|	");
			int weekday = convertWeekDay(fields[1]);
			TreeMap<Integer, Vector<Double>> hour_numberMap = weekday_hour_numberMap.get(weekday);
			if (hour_numberMap == null)
			{
				hour_numberMap = new TreeMap<Integer, Vector<Double>>();
				weekday_hour_numberMap.put(weekday, hour_numberMap);
			}
			
			int hour = Integer.parseInt(fields[2].substring(6));
			Vector<Double> numbers = hour_numberMap.get(hour);
			if (numbers == null)
			{
				numbers = new Vector<Double>();
				hour_numberMap.put(hour, numbers);
			}
			numbers.add(Double.parseDouble(fields[4]));
//			if (i%50 == 0)
//			{
//				double average = 0;
//				for (int j = 0; j < 50; ++j)
//				{
//					average += numbers.get(numbers.size()-1);
//					numbers.remove(numbers.size()-1);
//				}
//				average /= 50;
//				numbers.add(average);
//			}
		}
		
		Iterator<Map.Entry<Integer, TreeMap<Integer, Vector<Double>>>> iter = weekday_hour_numberMap.entrySet().iterator();
		while (iter.hasNext())
		{
			Map.Entry<Integer, TreeMap<Integer, Vector<Double>>> entry = iter.next();
			System.out.println(entry.getKey());
			for (Map.Entry<Integer, Vector<Double>> entry2 : entry.getValue().entrySet())
			{
				System.out.println(entry2.getKey());
				for (Double completion : entry2.getValue())
				{
					System.out.print(completion+" ");
				}
				System.out.println();
			}
		}
	}
	
	private void analyzeTaskCompletionWRTHour()
	{
		Vector<String> contents = readInputFile("batchCompletionRateDataI.data");
		TreeMap<Integer, Vector<Double>> hour_numberMap = new TreeMap<Integer, Vector<Double>>();
		for (int i = 1; i < contents.size()/2; ++i)
		{
			String s = contents.get(i);
			String[] fields = s.split("	|	");
			int hour = Integer.parseInt(fields[2].substring(6));
			Vector<Double> numbers = hour_numberMap.get(hour);
			if (numbers == null)
			{
				numbers = new Vector<Double>();
				hour_numberMap.put(hour, numbers);
			}
			numbers.add(Double.parseDouble(fields[4]));
//			if (i%50 == 0)
//			{
//				double average = 0;
//				for (int j = 0; j < 50; ++j)
//				{
//					average += numbers.get(numbers.size()-1);
//					numbers.remove(numbers.size()-1);
//				}
//				average /= 50;
//				numbers.add(average);
//			}
		}
		
		Iterator<Map.Entry<Integer, Vector<Double>>> iter = hour_numberMap.entrySet().iterator();
		while (iter.hasNext())
		{
			Map.Entry<Integer, Vector<Double>> entry = iter.next();
			System.out.println(entry.getKey()+" "+RunHelper.getInstance().calAvg(entry.getValue().iterator()));
		}
	}
	
	private void analyzeWorkerNumbers()
	{
		Vector<String> contents = readInputFile("MWWorkers.glb");
		TreeMap<String, TreeMap<String,Vector<String>>> workersInCountry = new TreeMap<String, TreeMap<String,Vector<String>>>();
		for (String s : contents)
		{
			String[] fields = s.split("	");
			TreeMap<String,Vector<String>> id_timeMap = workersInCountry.get(fields[1]);
			if (id_timeMap == null)
			{
				id_timeMap = new TreeMap<String,Vector<String>>();
				workersInCountry.put(fields[1], id_timeMap);
			}
			
			Vector<String> timeVec = id_timeMap.get(fields[0]);
			if (timeVec == null)
			{
				timeVec = new Vector<String>();
				id_timeMap.put(fields[0], timeVec);
			}
			
			String[] timeArray = fields[8].split(" ");
			for (String time : timeArray)
				timeVec.add(time);
		}
		
		Iterator<Map.Entry<String, TreeMap<String,Vector<String>>>> iter = workersInCountry.entrySet().iterator();
		while (iter.hasNext())
		{
			Map.Entry<String, TreeMap<String,Vector<String>>> entry = iter.next();
			System.out.println(entry.getKey());
			System.out.println(entry.getValue().size()+" "+entry.getValue().keySet());
			
			Iterator<Map.Entry<String, Vector<String>>> jter = entry.getValue().entrySet().iterator();
			while (jter.hasNext())
			{
				Map.Entry<String, Vector<String>> jEntry = jter.next();
			
			TreeSet<String> testSet = new TreeSet<String>();
			testSet.addAll(jEntry.getValue());
			if (testSet.size() != jEntry.getValue().size())
				System.out.println("Wrong");
			}
		}
	}
	
	public TreeMap<String, TreeMap<Integer, Pair<Double,Double>>> country_hour_available()
	{
		TreeMap<String, TreeMap<Integer, Pair<Double,Double>>> result = new TreeMap<String, TreeMap<Integer, Pair<Double,Double>>>();
		TreeMap<String, TreeMap<Integer, Vector<Double>>> country_hour_available = new TreeMap<String, TreeMap<Integer, Vector<Double>>>();
		Vector<String> contents = readInputFile("../crowdsourcing/MWWorkers.glb");
		TreeMap<String, Vector<String>> timeAvailable = new TreeMap<String, Vector<String>>();
		for (String s : contents)
		{
			String[] fields = s.split("	");
			Vector<String> datatime = new Vector<String>();
			String[] time = fields[8].split(" ");
			for (String s2: time)
				datatime.add(s2);
			
			Vector<String> values = timeAvailable.get(fields[1]);
			if (values == null)
				timeAvailable.put(fields[1], datatime);
			else
				values.addAll(datatime);
		}
		
		TreeMap<String, TreeMap<Integer, TreeMap<Integer, Integer>>> country_weekday_hour_numberMap = analyzeAvailableTime(timeAvailable, "201205210232", "201205272330");
		for (Map.Entry<String, TreeMap<Integer, TreeMap<Integer, Integer>>> entry : country_weekday_hour_numberMap.entrySet())
		{
			TreeMap<Integer, Vector<Double>> hour_available = country_hour_available.get(entry.getKey());
			if (hour_available == null)
			{
				hour_available = new TreeMap<Integer, Vector<Double>>();
				country_hour_available.put(entry.getKey(), hour_available);
			}
			for (Map.Entry<Integer, TreeMap<Integer, Integer>> entry2 : entry.getValue().entrySet())
			{
				for (int i = 0; i < 24; ++i)
				{
					int numberOfWorkers = entry2.getValue().get(i)==null?0:entry2.getValue().get(i);
					Vector<Double> availableVec = hour_available.get(i);
					if (availableVec == null)
					{
						availableVec = new Vector<Double>();
						hour_available.put(i, availableVec);
					}
					availableVec.add((double)numberOfWorkers);
				}
			}
		}
		
		for (Map.Entry<String, TreeMap<Integer, Vector<Double>>> entry : country_hour_available.entrySet())
		{
			TreeMap<Integer, Pair<Double,Double>> hour_num = new TreeMap<Integer, Pair<Double,Double>>();
			result.put(entry.getKey(), hour_num);
			for (Map.Entry<Integer, Vector<Double>> entry2 : entry.getValue().entrySet())
			{
				double average = RunHelper.getInstance().calAvg(entry2.getValue().iterator());
				double stdev = RunHelper.getInstance().calDevofVec(entry2.getValue());
				hour_num.put(entry2.getKey(), new Pair<Double,Double>(average,stdev));
			}
		}
		return result;
	}
	
	private void analyzeFrequency()
	{
		Vector<String> contents = readInputFile("MWWorkers.glb");
		TreeMap<String, Vector<String>> timeAvailable = new TreeMap<String, Vector<String>>();
		for (String s : contents)
		{
			String[] fields = s.split("	");
			Vector<String> datatime = new Vector<String>();
			String[] time = fields[8].split(" ");
			for (String s2: time)
				datatime.add(s2);
			
			Vector<String> values = timeAvailable.get(fields[1]);
			if (values == null)
				timeAvailable.put(fields[1], datatime);
			else
				values.addAll(datatime);
		}
		
//		for (Map.Entry<String, Vector<String>> entry : timeAvailable.entrySet())
//		{
//			System.out.println(entry.getKey()+" "+entry.getValue().size());
//		}
		
		TreeMap<String, TreeMap<Integer, TreeMap<Integer, Integer>>> country_weekday_hour_numberMap = analyzeAvailableTime(timeAvailable, "201205210232", "201205272330");
		for (Map.Entry<String, TreeMap<Integer, TreeMap<Integer, Integer>>> entry : country_weekday_hour_numberMap.entrySet())
		{
			System.out.println(entry.getKey());
			for (Map.Entry<Integer, TreeMap<Integer, Integer>> entry2 : entry.getValue().entrySet())
			{
				System.out.println(entry2.getKey());
				for (int i = 0; i < 24; ++i)
				{
					System.out.print((entry2.getValue().get(i)==null?0:entry2.getValue().get(i))+" ");
				}
				System.out.println();
			}
		}
	}

	private void analyzeFrequencyPerTimeSlot()
	{
		Vector<String> contents = readInputFile("MWWorkers.glb");
		
		TreeMap<String, Vector<Double>> frequencyPerTime = new TreeMap<String, Vector<Double>>();
		for (String s : contents)
		{
			String[] fields = s.split("	");
			String country = fields[1];
			if (!(country.equals("US") || country.equals("PH") || country.equals("IN")))
			{
				country = "Others";
			}
			Vector<Double> frequencyVec = frequencyPerTime.get(country);
			if (frequencyVec == null)
			{
				frequencyVec = new Vector<Double>();
				frequencyPerTime.put(country, frequencyVec);
			}
			double frequency = Double.parseDouble(fields[5]);
			Vector<String> datatime = new Vector<String>();
			String[] time = fields[8].split(" ");
			frequency /= time.length;
			frequencyVec.add(frequency);
		}
		
		for (Map.Entry<String, Vector<Double>> frequency : frequencyPerTime.entrySet())
		{
			System.out.println(frequency.getKey());
			for (Double d : frequency.getValue())
				System.out.println(d);
		}
	}
	
	private TreeMap<String, Double> worker_serviceTime()
	{
		Vector<String> contents = readInputFile("MWWorkers.glb");
		TreeMap<String, Double> result = new TreeMap<String, Double>();
		for (String s : contents)
		{
			String[] fields = s.split("	");
			if (result.containsKey(fields[0]))
			{
				System.out.println("Wrong");
			}
			result.put(fields[0], Double.parseDouble(fields[7]));
		}
		return result;
	}
	
	private void analyzeCountry_serviceTime()
	{
		TreeMap<String, Double> worker_serviceTime = worker_serviceTime();
		TreeMap<String, TreeMap<Integer, Vector<String>>> country_weekday_ids = country_weekday_ids();
		for (Map.Entry<String, TreeMap<Integer, Vector<String>>> entry : country_weekday_ids.entrySet())
		{
			System.out.println(entry.getKey());
			TreeSet<String> ids = new TreeSet<String>();
			for (Map.Entry<Integer, Vector<String>> entry2 : entry.getValue().entrySet())
			{
				ids.addAll(entry2.getValue());
			}
			for (String id : ids)
			{
				Double serviceTime = worker_serviceTime.get(id);
				if (serviceTime == null)
					System.out.println("Wrong");
				System.out.print(serviceTime+" ");
			}
			System.out.println();
		}
	}
	
	private void analyzeCountry_weekday_serviceTime()
	{
		TreeMap<String, Double> worker_serviceTime = worker_serviceTime();
		TreeMap<String, TreeMap<Integer, Vector<String>>> country_weekday_ids = country_weekday_ids();
		for (Map.Entry<String, TreeMap<Integer, Vector<String>>> entry : country_weekday_ids.entrySet())
		{
			System.out.println(entry.getKey());
			for (Map.Entry<Integer, Vector<String>> entry2 : entry.getValue().entrySet())
			{
				System.out.print(entry2.getKey()+" ");
				double averageServiceTime = 0;
				for (String id : entry2.getValue())
				{
					Double serviceTime = worker_serviceTime.get(id);
					if (serviceTime == null)
						System.out.println("Wrong");
					else
					{
						averageServiceTime += serviceTime;
					}
				}
				averageServiceTime /= entry2.getValue().size();
				System.out.println(averageServiceTime);
			}
		}
	}
	
	private void analyzeWorkerWRTWeekday()
	{
		Vector<String> contents = readInputFile("MWWorkers.glb");
		TreeMap<Integer, TreeMap<String, Integer>> weekday_id_frequency = new TreeMap<Integer, TreeMap<String, Integer>>();
		for (String s : contents)
		{
			String[] fields = s.split("	");
			
			String[] time = fields[8].split(" ");
			for (String s2: time)
			{
				int weekday = parseWeekday(s2);
				TreeMap<String, Integer> id_frequency = weekday_id_frequency.get(weekday);
				if (id_frequency == null)
				{
					id_frequency = new TreeMap<String, Integer>();
					id_frequency.put(fields[0], 1);
					weekday_id_frequency.put(weekday, id_frequency);
				}
				else
				{
					Integer frequency = id_frequency.get(fields[0]);
					if (frequency == null)
						id_frequency.put(fields[0], 1);
					else
						id_frequency.put(fields[0], frequency+1);
				}				
			}
		}
		
		TreeMap<String, Double> id_serviceTime = worker_serviceTime();
		
		for (Map.Entry<Integer, TreeMap<String, Integer>> entry : weekday_id_frequency.entrySet())
		{
			System.out.println(entry.getKey());
			double averageServiceTime = 0;
			int num = 0;
			for (Map.Entry<String, Integer> entry2 : entry.getValue().entrySet())
			{
				averageServiceTime += id_serviceTime.get(entry2.getKey())*entry2.getValue();
				num += entry2.getValue();
			}
			averageServiceTime /= num;
			System.out.println(averageServiceTime);
		}
	}
	
	private TreeMap<String, TreeMap<Integer, TreeMap<Integer, Integer>>> analyzeAvailableTime(TreeMap<String, Vector<String>> arg, String earliestDate, String latestDate)
	{
		Date earlydate = null;
		Date latedate = null;
		try
		{
			latedate = new SimpleDateFormat("yyyyMMddHHmm").parse(latestDate);
			earlydate = new SimpleDateFormat("yyyyMMddHHmm").parse(earliestDate);
		}
		catch (ParseException e)
		{
			e.printStackTrace();
		}
		
		
		TreeMap<String, TreeMap<Integer, TreeMap<Integer, Integer>>> country_weekday_hour_numberMap = new TreeMap<String, TreeMap<Integer, TreeMap<Integer, Integer>>>();
		for (Map.Entry<String, Vector<String>> entry : arg.entrySet())
		{
			String country = entry.getKey();
			if (!(country.equals("US") || country.equals("PH") || country.equals("IN")))
			{
				country = "Other";
			}
			TreeMap<Integer, TreeMap<Integer, Integer>> weekday_hour_numberMap = country_weekday_hour_numberMap.get(country);
			if (weekday_hour_numberMap == null)
			{
				weekday_hour_numberMap = new TreeMap<Integer, TreeMap<Integer, Integer>>();
				country_weekday_hour_numberMap.put(country, weekday_hour_numberMap);
			}
			
			for (String time : entry.getValue())
			{
				Date date = null;
				try
				{
					date = new SimpleDateFormat("yyyyMMddHHmm").parse(time);
				}
				catch (ParseException e)
				{
					e.printStackTrace();
				}
				if (date.after(latedate) || date.before(earlydate))
					continue;
				
				int weekday = parseWeekday(time);
				TreeMap<Integer, Integer> hour_numberMap = weekday_hour_numberMap.get(weekday);
				if (hour_numberMap == null)
				{
					hour_numberMap = new TreeMap<Integer, Integer>();
					weekday_hour_numberMap.put(weekday, hour_numberMap);
				}
				
				int hour = parseHour(time);				
				Integer frequency = hour_numberMap.get(hour);
				if (frequency == null)
					hour_numberMap.put(hour, 1);
				else
					hour_numberMap.put(hour, frequency+1);
			}
		}
				
		return country_weekday_hour_numberMap;
	}
	
	private void analyzeID_Time()
	{
		TreeMap<String, Vector<String>> country_ids = country_ids();
		TreeMap<String, Vector<String>> id_availableTime = id_availableTime();
		for (Map.Entry<String, Vector<String>> country_idEntry : country_ids.entrySet())
		{
			TreeMap<Integer, Vector<String>> availableNumber_id = new TreeMap<Integer, Vector<String>>(new Comparator<Integer>() {
				  public int compare(Integer a, Integer b) { return b.compareTo(a); }});
			for (String id : country_idEntry.getValue())
			{
				Vector<String> availableTimes = id_availableTime.get(id);
				Vector<String> ids = availableNumber_id.get(availableTimes.size());
				if (ids == null)
				{
					ids = new Vector<String>();
					availableNumber_id.put(availableTimes.size(), ids);
				}
				ids.add(id);
			}
			
			int idIndex = 1;
			System.out.println(country_idEntry.getKey());
			for (Map.Entry<Integer, Vector<String>> number_idEntry : availableNumber_id.entrySet())
			{
				for (String id : number_idEntry.getValue())
				{
					Vector<String> availableTimes = id_availableTime.get(id);
					for (String time : availableTimes)
					{
						int difference = timeDiffInHour("201205210000", time);
						System.out.println(idIndex+" "+difference);
					}
					idIndex++;
				}
				
			}
		
		}
	}
	
	private int timeDiffInHour(String arg1, String arg2)
	{
		int result = 0;
		int day1 = Integer.parseInt(arg1.substring(6, 8));
		int day2 = Integer.parseInt(arg2.substring(6, 8));
		int hour1 = Integer.parseInt(arg1.substring(8,10));
		int hour2 = Integer.parseInt(arg2.substring(8,10));
		result = (day2-day1)*24+(hour2-hour1);
		return result;
	}
	
	private TreeMap<String, TreeMap<Integer, Vector<String>>> country_weekday_ids()
	{
		Vector<String> contents = readInputFile("MWWorkers.glb");
		TreeMap<String, TreeMap<Integer, Vector<String>>> country_weekday_ids = new TreeMap<String, TreeMap<Integer, Vector<String>>>();
		for (String s : contents)
		{
			String[] fields = s.split("	");
	
			String country = fields[1];
			if (!(country.equals("US") || country.equals("PH") || country.equals("IN")))
			{
				country = "Others";
			}
			TreeMap<Integer, Vector<String>> weekday_ids = country_weekday_ids.get(country);
			if (weekday_ids == null)
			{
				weekday_ids = new TreeMap<Integer, Vector<String>>();
				country_weekday_ids.put(country, weekday_ids);
			}
			
			for (String time : fields[8].split(" "))
			{				
				int weekday = parseWeekday(time);
				Vector<String> ids = weekday_ids.get(weekday);
				if (ids == null)
				{
					ids = new Vector<String>();
					weekday_ids.put(weekday, ids);
				}
				ids.add(fields[0]);
			}
		}
				
		return country_weekday_ids;
	}
	
	private TreeMap<String, Vector<String>> country_ids()
	{
		Vector<String> contents = readInputFile("MWWorkers.glb");
		TreeMap<String, Vector<String>> country_ids = new TreeMap<String, Vector<String>>();
		for (String s : contents)
		{
			String[] fields = s.split("	");
	
			String country = fields[1];
			if (!(country.equals("US") || country.equals("PH") || country.equals("IN")))
			{
				country = "Others";
			}
			Vector<String> ids = country_ids.get(country);
			if (ids == null)
			{
				ids = new Vector<String>();
				country_ids.put(country, ids);
			}
			
			ids.add(fields[0]);
		}
				
		return country_ids;
	}
	
	private TreeMap<String, Vector<String>> id_availableTime()
	{
		Vector<String> contents = readInputFile("MWWorkers.glb");
		TreeMap<String, Vector<String>> timeAvailable = new TreeMap<String, Vector<String>>();
		for (String s : contents)
		{
			String[] fields = s.split("	");
			Vector<String> datatime = new Vector<String>();
			String[] time = fields[8].split(" ");
			for (String s2: time)
				datatime.add(s2);
			
			Vector<String> values = timeAvailable.get(fields[1]);
			if (values == null)
				timeAvailable.put(fields[0], datatime);
			else
				values.addAll(datatime);
		}
		return timeAvailable;
	}
	
	private Date GenerateDate(String arg)
	{
		Date date = null;
		try
		{
			date = new SimpleDateFormat("yyyyMMddHHmm").parse(arg);
		}
		catch (ParseException e)
		{
			e.printStackTrace();
		}
		return date;
	}
	
	private int parseWeekday(String arg)
	{
		Date date = GenerateDate(arg);
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		return calendar.get(Calendar.DAY_OF_WEEK);
	}
	
	private int parseHour(String arg)
	{
		Date date = null;
		try
		{
			date = new SimpleDateFormat("yyyyMMddHHmm").parse(arg);
		}
		catch (ParseException e)
		{
			e.printStackTrace();
		}
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		return calendar.get(Calendar.HOUR_OF_DAY);
	}
	
	private Vector<String> readInputFile(String filename)
	{
		Vector<String> result = new Vector<String>();
		FileInputStream fstream = null;
		try
		{
			fstream = new FileInputStream(filename);
		}
		catch (FileNotFoundException e1)
		{
			e1.printStackTrace();
		}
		BufferedReader reader = new BufferedReader(new InputStreamReader(fstream));
		String strLine = "";
		try
		{
			while ((strLine=reader.readLine()) != null)
			{
				result.add(strLine);
			}
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}
		try
		{
			fstream.close();
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}
		return result;
	}
	
	private int convertWeekDay(String arg)
	{
		int result = 0;
		if (arg.toLowerCase().equals("monday"))
			result = Calendar.MONDAY;
		else if (arg.toLowerCase().equals("tuesday"))
			result = Calendar.TUESDAY;
		else if (arg.toLowerCase().equals("wednesday"))
			result = Calendar.WEDNESDAY;
		else if (arg.toLowerCase().equals("thursday"))
			result = Calendar.THURSDAY;
		else if (arg.toLowerCase().equals("friday"))
			result = Calendar.FRIDAY;
		else if (arg.toLowerCase().equals("saturday"))
			result = Calendar.SATURDAY;
		else if (arg.toLowerCase().equals("sunday"))
			result = Calendar.SUNDAY;
		else
			System.out.println("Error in weekdays");
		return result;
	}
}