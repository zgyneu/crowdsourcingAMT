package analytics;

import java.util.BitSet;
import java.util.Iterator;
import java.util.Vector;

public class RunHelper
{
	public static RunHelper getInstance()
	{
		if (singleInstance == null)
		{
			singleInstance = new RunHelper();
		}
		return singleInstance;
	}
	
	private RunHelper()
	{}
	
	public int calNumOfIter(Iterable iter)
	{
		if (iter == null)
			return 0;
		int result = 0;
		Iterator iterator = iter.iterator();
		while (iterator.hasNext())
		{
			result ++;
			iterator.next();
		}
		return result;
	}
	
	public double calSumofIter(Iterator iter)
	{
		double result = 0;
		while (iter.hasNext())
		{
			result += (Double)iter.next();
		}
		return result;
	}
	
	public double calSumofArray(double[] array)
	{
		double result = 0;
		for (int i = 0; i < array.length; ++i)
		{
			result += array[i];
		}
		return result;
	}
	
	public double calAvg(Iterator iter)
	{
		double result = 0;
		int num = 0;
		while (iter.hasNext())
		{
			Object element = iter.next();
			if (element instanceof Integer)
				result += (Integer)element;
			else
				result += (Double)element;
			num++;
		}
		return result/num;
	}
	
	public double calAvg(double[] array)
	{
		double result = 0;
		for (int i = 0; i < array.length; ++i)
		{
			result += array[i];
		}
		return result/array.length;
	}
	
	public int maxIndex(double[] array)
	{
		int result = 0;
		double max = array[result];
		for (int i = 1; i < array.length; ++i)
		{
			if (array[i] > max)
			{
				max = array[i];
				result = i;
			}
		}
		return result;
	}
	
	public int maxIndex(Vector<Double> array)
	{
		int result = 0;
		double max = array.get(result);
		for (int i = 1; i < array.size(); ++i)
		{
			if (array.get(i) > max)
			{
				max = array.get(i);
				result = i;
			}
		}
		return result;
	}
	
	public double max(double[] array)
	{
		double max = array[0];
		for (int i = 1; i < array.length; ++i)
		{
			if (array[i] > max)
			{
				max = array[i];
			}
		}
		return max;
	}
	
	public <T> double calDevofVec(Vector<T> vec)
	{
		double avg = calAvg(vec.iterator());
		double result = 0;
		for (int i = 0; i < vec.size(); ++i)
		{
			result += Math.pow((Double)vec.get(i)-avg, 2);
		}
		return Math.sqrt(result/(vec.size()-1));
	}
	
	public void printLineNO()
	{
		System.out.println(new Exception().getStackTrace()[1].getLineNumber());
	}
	
	public boolean inRange(int min, int max, double value)
	{
		boolean result = false;
		if (value == 360)
			value = 0;
		if (min > max)
		{
			if (value >= min || value < max)
			{
				result = true; 
			}
		}
		else
		{
			if (value >= min && value < max)
			{
				result = true;
			}
		}
		return result;
	}
	
	public int convertBinaryToDecimal(BitSet gene, int numBits)
	{
		boolean[] bools = new boolean[numBits];
		for (int k = 0; k < numBits; ++k)
		{
			bools[numBits-1-k] = gene.get(k);
		}
		return ConvertBinaryToDecimal(bools);
	}
	
	public int ConvertBinaryToDecimal(boolean[] args)
	{
		int result = 0;
		for (int i = 0; i < args.length; ++i)
		{
			result += (int)((args[i]?1:0)*Math.pow(2, i));
		}
		return result;
	}
	
	public BitSet convertIntToBin(int arg, int numBits)
	{
		BitSet gene = new BitSet();
		String s = Integer.toBinaryString(arg);
		for (int i = 0; i < numBits; ++i)
		{
			if ((numBits - i - 1 < s.length()) && (s.charAt(s.length() - numBits + i) == '1'))
				gene.set(i, true);
			else
				gene.set(i, false);
		}
		return gene;
	}
	
	private static RunHelper singleInstance = null;
}
