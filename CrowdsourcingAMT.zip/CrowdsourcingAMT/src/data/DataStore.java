package data;

import java.util.HashMap;
import java.util.HashSet;
import java.util.TreeMap;
import java.util.Vector;

import crowdsourcing.Agent;
import crowdsourcing.Task;

public class DataStore {
	private static DataStore instance = null;
	public Vector<Task> g_tasks = new Vector<Task>();
	public TreeMap<String, Integer> g_availability = new TreeMap<String, Integer>();
	public TreeMap<Integer, HashSet<Agent>> g_numberOfWorkers = new TreeMap<Integer, HashSet<Agent>>();
	public TreeMap<Integer, HashMap<Agent,Integer>> g_numberOfTasksPerWorker = new TreeMap<Integer, HashMap<Agent,Integer>>();
	public TreeMap<Integer, HashMap<Agent,Integer>> g_showupPerDay = new TreeMap<Integer, HashMap<Agent,Integer>>();
	 
    private DataStore() {       }

    public static synchronized DataStore getInstance() {
        if (instance == null) {
                instance = new DataStore ();
        }
        return instance;
    }
    
    public void updateNumberOfWorkers(int currentTick, Agent worker)
	{
		// update g_numberOfWorkers
		HashSet<Agent> numberOfWorkers = g_numberOfWorkers.get((int)(currentTick-1)/(60*24));
		if (numberOfWorkers == null)
		{
			numberOfWorkers = new HashSet<Agent>();
			g_numberOfWorkers.put((int)(currentTick-1)/(60*24), numberOfWorkers);
		}
		numberOfWorkers.add(worker);
	}
	
	public void updateNumberOfTasksPerWorker(Agent worker, int currentTick, int numberOfTasks)
	{
		 HashMap<Agent,Integer> worker_TasksMap = g_numberOfTasksPerWorker.get((currentTick-1)/(60*24));
		if (worker_TasksMap == null)
		{
			worker_TasksMap = new  HashMap<Agent,Integer>();
			g_numberOfTasksPerWorker.put((currentTick-1)/(60*24), worker_TasksMap);
		}
		Integer numTasks = worker_TasksMap.get(worker);
		if (numTasks == null)
			worker_TasksMap.put(worker, numberOfTasks);
		else
			worker_TasksMap.put(worker, numTasks + numberOfTasks);
	}
	
	public void updateShowupPerDay(Agent worker, int currentTick)
	{
		 HashMap<Agent,Integer> worker_TasksMap = g_showupPerDay.get((currentTick-1)/(60*24));
		if (worker_TasksMap == null)
		{
			worker_TasksMap = new  HashMap<Agent,Integer>();
			g_showupPerDay.put((currentTick-1)/(60*24), worker_TasksMap);
		}
		Integer numTasks = worker_TasksMap.get(worker);
		if (numTasks == null)
			worker_TasksMap.put(worker, 1);
		else
			worker_TasksMap.put(worker, numTasks + 1);
	}
	
	public void clearAll()
	{
		g_tasks.clear();
		g_availability.clear();
		g_numberOfWorkers.clear();
		g_numberOfTasksPerWorker.clear();
		g_showupPerDay.clear();
	}

}
