package lib;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.BitSet;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import java.util.Vector;

public class RunHelper
{
	public static RunHelper getInstance()
	{
		if (singleInstance == null)
		{
			singleInstance = new RunHelper();
		}
		return singleInstance;
	}
	
	private RunHelper()
	{}
	
	public int[] numberDigitConversion(int value, int denominator, int numberDigits, int shift)
	{
		int[] result = new int[numberDigits];
		for (int i = numberDigits-1; i >= 0; --i)
		{
			if (i == 0)
				result[i] = value % denominator;
			else
			{
				result[i] = (int)(value/Math.pow(denominator, i)% denominator);	
			}
			
			result[i] += shift;
		}
		
		return result;
	}
	
	public int calNumOfIter(Iterable iter)
	{
		if (iter == null)
			return 0;
		int result = 0;
		Iterator iterator = iter.iterator();
		while (iterator.hasNext())
		{
			result ++;
			iterator.next();
		}
		return result;
	}
	
	public double calSumofIter(Iterator iter)
	{
		double result = 0;
		while (iter.hasNext())
		{
			result += (Double)iter.next();
		}
		return result;
	}
	
	public double calSumofArray(double[] array)
	{
		double result = 0;
		for (int i = 0; i < array.length; ++i)
		{
			result += array[i];
		}
		return result;
	}
	
	public double calAvg(Iterator iter)
	{
		double result = 0;
		int num = 0;
		while (iter.hasNext())
		{
			Object element = iter.next();
			if (element instanceof Integer)
				result += (Integer)element;
			else
				result += (Double)element;
			num++;
		}
		return result/num;
	}
	
	public double calAvg(double[] array)
	{
		double result = 0;
		for (int i = 0; i < array.length; ++i)
		{
			result += array[i];
		}
		return result/array.length;
	}
	
	public int maxIndex(double[] array)
	{
		int result = 0;
		double max = array[result];
		for (int i = 1; i < array.length; ++i)
		{
			if (array[i] > max)
			{
				max = array[i];
				result = i;
			}
		}
		return result;
	}
	
	public int maxIndex(Vector<Double> array)
	{
		int result = 0;
		double max = array.get(result);
		for (int i = 1; i < array.size(); ++i)
		{
			if (array.get(i) > max)
			{
				max = array.get(i);
				result = i;
			}
		}
		return result;
	}
	
	public double max(double[] array)
	{
		double max = array[0];
		for (int i = 1; i < array.length; ++i)
		{
			if (array[i] > max)
			{
				max = array[i];
			}
		}
		return max;
	}
	
	public double max(Vector<Double> vec)
	{
		double max = vec.get(0);
		for (int i = 1; i < vec.size(); ++i)
		{
			if (vec.get(i) > max)
			{
				max = vec.get(i);
			}
		}
		return max;
	}
	
	public double min(Vector<Double> vec)
	{
		double min = vec.get(0);
		for (int i = 1; i < vec.size(); ++i)
		{
			if (vec.get(i) < min)
			{
				min = vec.get(i);
			}
		}
		return min;
	}
	
	public <T> double calDevofVec(Vector<T> vec)
	{
		double avg = calAvg(vec.iterator());
		double result = 0;
		for (int i = 0; i < vec.size(); ++i)
		{
			result += Math.pow((Double)vec.get(i)-avg, 2);
		}
		return Math.sqrt(result/(vec.size()-1));
	}
	
	public Pair<Double,Double> boxPlotOutliers(Vector<Double> vec)
	{
		Pair<Double,Double> result = new Pair<Double,Double>();
		double median = median(vec);
		double stdev = calDevofVec(vec);
		double lowerbound = median - 2.698 * stdev;
		double upperbound = median + 2.698 * stdev;
		result.setVar1(lowerbound);
		result.setVar2(upperbound);
		return result;
	}
	
	public Double median(Vector<Double> vec)
	{
		Double[] array = new Double[vec.size()];
		vec.toArray(array);
		Arrays.sort(array);
		int middle = array.length/2;
		if (array.length % 2 == 0)
			return (array[middle-1]+array[middle])/2;
		else
			return array[middle];
	}
	
	public void printLineNO()
	{
		System.out.println(new Exception().getStackTrace()[1].getLineNumber());
	}
	
	public boolean inRange(int min, int max, double value)
	{
		boolean result = false;
		if (value == 360)
			value = 0;
		if (min > max)
		{
			if (value >= min || value < max)
			{
				result = true; 
			}
		}
		else
		{
			if (value >= min && value < max)
			{
				result = true;
			}
		}
		return result;
	}
	
	public int convertBinaryToDecimal(BitSet gene, int numBits)
	{
		boolean[] bools = new boolean[numBits];
		for (int k = 0; k < numBits; ++k)
		{
			bools[numBits-1-k] = gene.get(k);
		}
		return ConvertBinaryToDecimal(bools);
	}
	
	public int ConvertBinaryToDecimal(boolean[] args)
	{
		int result = 0;
		for (int i = 0; i < args.length; ++i)
		{
			result += (int)((args[i]?1:0)*Math.pow(2, i));
		}
		return result;
	}
	
	public BitSet convertIntToBin(int arg, int numBits)
	{
		BitSet gene = new BitSet();
		String s = Integer.toBinaryString(arg);
		for (int i = 0; i < numBits; ++i)
		{
			if ((numBits - i - 1 < s.length()) && (s.charAt(s.length() - numBits + i) == '1'))
				gene.set(i, true);
			else
				gene.set(i, false);
		}
		return gene;
	}
	
	public Vector<String> readInputFile(String filename)
	{
		Vector<String> result = new Vector<String>();
		FileInputStream fstream = null;
		try
		{
			fstream = new FileInputStream(filename);
		}
		catch (FileNotFoundException e1)
		{
			e1.printStackTrace();
		}
		BufferedReader reader = new BufferedReader(new InputStreamReader(fstream));
		String strLine = "";
		try
		{
			while ((strLine=reader.readLine()) != null)
			{
				result.add(strLine);
			}
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}
		try
		{
			fstream.close();
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}
		return result;
	}
	
	private static RunHelper singleInstance = null;
}
