package lib;

public class Pair<T1, T2>
{
	public Pair()
	{}
	
	public Pair(T1 t1, T2 t2)
	{
		m_var1 = t1;
		m_var2 = t2;
	}
	
	public T1 getVar1()
	{
		return m_var1;
	}
	
	public T2 getVar2()
	{
		return m_var2;
	}
	
	public void setVar1(T1 v1)
	{
		m_var1 = v1;
	}
	
	public void setVar2(T2 v2)
	{
		m_var2 = v2;
	}
	
	@Override
	public String toString()
	{
		return m_var1+", "+m_var2;
	}

	private T1 m_var1;
	private T2 m_var2;
}