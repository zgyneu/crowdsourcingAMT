package lib;

import java.util.Vector;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class StringHelper
{
	public static String parseRegEx(String argStr, String regEx)
	{
		String result = null;
		Pattern p = Pattern.compile(regEx);
		Matcher m = p.matcher(argStr);
		if (m.find())
		{
			result = m.group(1);
		}
		return result;
	}
	
	public static Vector<String> parseRegExAllOccurrences(String argStr, String regEx)
	{
		Vector<String> result = new Vector<String>();
		Pattern p = Pattern.compile(regEx);
		while (true)
		{
			Matcher m = p.matcher(argStr);
			if (m.find())
			{
				result.add(m.group(1));
				argStr = argStr.substring(m.end());
			}
			else
				break;
		}
		return result;
	}
}
