package lib;

import cern.jet.random.Uniform;
import repast.simphony.random.RandomHelper;

public class UniformLinearRegressionGenerator {

	private double m_regressionResult;
	private double m_regressionR2;
	private Uniform m_uniformDist;
	
	public UniformLinearRegressionGenerator(double regressionResult, double regressionR2)
	{
		m_regressionResult = regressionResult;
		m_regressionR2 = regressionR2;
		m_uniformDist = RandomHelper.createUniform(0, 1);
	}
	
	public boolean isTrue()
	{
		double regressionResult = m_uniformDist.nextDouble();
		double regressionR2 = m_uniformDist.nextDouble();
		boolean result = false;
		if ( regressionR2 <= m_regressionR2)
		{
			result = regressionResult <= m_regressionResult;
		}
		else 
		{
			result = regressionResult > m_regressionResult;
		}
		return result;
	}
}
