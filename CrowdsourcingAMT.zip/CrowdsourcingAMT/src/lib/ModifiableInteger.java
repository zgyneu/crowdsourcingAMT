package lib;

public class ModifiableInteger
{
	public int value;
}
