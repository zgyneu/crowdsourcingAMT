package lib;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.Vector;


public class FileHelper
{	
	public static String findInFile(String filename, String str)
	{
		String result = null;
		FileInputStream fstream = null;
		try
		{
			fstream = new FileInputStream(filename);
		}
		catch (FileNotFoundException e1)
		{
			e1.printStackTrace();
		}
		BufferedReader reader = new BufferedReader(new InputStreamReader(fstream));
		String strLine = "";
		try
		{
			while ((strLine=reader.readLine()) != null)
			{
				if (strLine.contains(str))
				{
					result = strLine;
					break;
				}
			}
			reader.close();
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}
		return result;
	}
	
	public static void writeFile(String fileName, String line)
	{
		try
		{
			PrintWriter out = new PrintWriter(new FileWriter(fileName, true), true);
			out.println(line);
			out.close();
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}
	}
	
	public static void writeFile(String fileName, Vector<String> contents)
	{
		try
		{
			PrintWriter out = new PrintWriter(new FileWriter(fileName, false), true);
			for (String line : contents)
				out.println(line);
			out.close();
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}
	}
	
	public static Vector<String> readFile(String filename)
	{
		Vector<String> result = new Vector<String>();
		FileInputStream fstream = null;
		try
		{
			fstream = new FileInputStream(filename);
		}
		catch (FileNotFoundException e1)
		{
			e1.printStackTrace();
		}
		BufferedReader reader = new BufferedReader(new InputStreamReader(fstream));
		String strLine = "";
		try
		{
			while ((strLine=reader.readLine()) != null)
			{
				result.add(strLine);
			}
			reader.close();
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}
		return result;
	}
}
