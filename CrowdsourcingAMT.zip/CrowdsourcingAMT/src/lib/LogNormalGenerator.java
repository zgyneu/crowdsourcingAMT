package lib;

import repast.simphony.random.RandomHelper;
import cern.jet.random.Normal;

public class LogNormalGenerator {
	
	private Normal normal = null;
	private double mu = 0;
	private double sigma = 0;
	
	public LogNormalGenerator(double mu, double sigma)
	{
		normal = RandomHelper.createNormal(0, 1);
		this.mu = mu;
		this.sigma = sigma;
	}
	
	public double nextDouble()
	{
		double result = 0;
		double nextDouble = normal.nextDouble();
		double x = mu+sigma*nextDouble;
		result = Math.exp(x);
		return result;
	}

}
