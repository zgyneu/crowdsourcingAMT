package RunCrowdsourcing;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Vector;

import optimization.SPSAClass;
import lib.FileHelper;
import lib.RunHelper;
import algorithm.Chromosomes;
import algorithm.GeneticAlgorithm;
import algorithm.Individual;
import algorithm.RunModelForCrowdSoucing;
import algorithm.RunModelForCrowdSoucingOptimization;
import algorithm.SimplexGAforCrowdSourcing;
import algorithm.SimplexGAforCrowdSourcingOptimization;
import crowdsourcing.Task;
import data.DataStore;
import repast.simphony.engine.environment.RunEnvironment;
import repast.simphony.parameter.Parameters;

public class RunSimulationModelAMT
{
	
	public static void main(String[] args)
	{
		double[] metrics = new RunSimulationModelAMT().getTargetMetrics();
//		new SPSAClass(metrics, new RunModelForCrowdSoucing()).run();
//		new SimplexGAforCrowdSourcing(100, 20, 10, metrics, new RunModelForCrowdSoucing()).run();

//		new RunSimulationModelAMT().SensitivityAnalysis();
//		new RunSimulationModelAMT().BatchRun();
		
		new RunSimulationModelAMT().optimizePosting();
	}	
	
	private void optimizePosting()
	{
		double[] metrics = new double[]{9900, 60};
		new SimplexGAforCrowdSourcingOptimization(100, 9, 10, metrics, new RunModelForCrowdSoucingOptimization()).run();
	}
	
	public RunSimulationModelAMT()
	{
//		ContextCreator.g_metrics = new Vector<Vector<Double>>();
//		for (int i = 0; i < g_metricSize; ++i)
//		{
//			ContextCreator.g_metrics.add(new Vector<Double>());
//		}
	}
	
	private void BatchRun()
	{
		RunModelForCrowdSoucing runModel = new RunModelForCrowdSoucing();
//		Individual chromosome = new Individual(1);
//		chromosome.set(0, 0.65);

		Date timeStart = new Date();
		
		for (int replications = 0; replications < 30; ++replications)
		{
			HashMap<String, Double> result = runModel.run(null, ""+(replications+1));
			//System.out.println(result);
//			TreeSet<String> keys = new TreeSet<String>(result.keySet());;
////			for (String key : keys)
////				System.out.println(key+" "+result.get(key));
			Vector<Task> metrics = DataStore.getInstance().g_tasks;
			double sumWorkingTime = 0;
			double sumAcceptingTime = 0;
			double sumAccuracy = 0;
			int num = 0;
			int num_task = 30;
			for (int i = 0; i < metrics.size(); ++i)
			{
				if (metrics.get(i).get_endTime() != Integer.MAX_VALUE)
				{
					sumWorkingTime += metrics.get(i).get_endTime() - metrics.get(i).get_startTime();
					sumAcceptingTime += metrics.get(i).get_startTime() - metrics.get(i).getPostTime();
					sumAccuracy += metrics.get(i).getAccuracy();
					++num;					
				}
				
				
				
				if ((i+1)%(num_task) == 0)
				{
					System.out.print("AcceptingTime: "+sumAcceptingTime/num+" "+"WorkingTime: "+sumWorkingTime/num+" "+"Accuracy: "+sumAccuracy/num+" "+"AcceptanceRate: "+(double)num/num_task+" ");
					sumWorkingTime = 0;
					sumAcceptingTime = 0;
					sumAccuracy = 0;
					num = 0;
				}
			}
			
			
//			for (Map.Entry<Integer, HashSet<Agent>> entry : JCrowdsourcingBuilder.g_numberOfWorkers.entrySet())
//			{
////				sum += entry.getValue();
////				if ((entry.getKey()+1)%24==0)
////				{
//					System.out.print(entry.getValue().size()+" ");
////					sum = 0;
////				}
//			}
//			
//			
//			for (Map.Entry<Integer, HashMap<Agent,Integer>> entry : JCrowdsourcingBuilder.g_numberOfTasksPerWorker.entrySet())
//			{
//				sum = 0;
//				for (Map.Entry<Agent,Integer> entry2 : entry.getValue().entrySet())
//				{
//					sum += entry2.getValue();
//				}
//				System.out.print(sum/entry.getValue().size()+" ");
//			}
			System.out.println();
		}
		
		Date timeEnd = new Date();
//		System.out.println((timeEnd.getTime() - timeStart.getTime())/1000.0);
	}
	
	private void SensitivityAnalysis()
	{
		String acceptingTimeString = "-4.777,0.83098;0.05362,-0.0006073;0.09645,0.06624;-0.05985,-0.10327;-0.07155,0.18001;-0.0008997,-0.00529;0.02643,-0.06489;0.02531,0.00508;-0.03589,0.02342;7.180,1.139";
		String[] acceptingTimeParams = acceptingTimeString.split(",|;");
		for (int j = 0; j < (int)Math.pow(3, acceptingTimeParams.length/2); ++j)
		{
			int[] permutation = RunHelper.getInstance().numberDigitConversion(j, 3, acceptingTimeParams.length/2, -1);

		Individual chromosome = new Individual(acceptingTimeParams.length);
		for (int i = 0; i < acceptingTimeParams.length; ++i) {
			if (i % 2 == 0)
				chromosome.set(i, Double.parseDouble(acceptingTimeParams[i])*(1+permutation[i/2]*0.1));
			else
				chromosome.set(i, Double.parseDouble(acceptingTimeParams[i]));
		}
		
			recursiveRun(chromosome, 0);
		}
		
		
	}
	
	private void recursiveRun(Individual chromosome, int index)
	{		
		double[] metrics = new RunSimulationModelAMT().getTargetMetrics();
		SimplexGAforCrowdSourcing GAObject = new SimplexGAforCrowdSourcing(100, 1, 10, metrics, new RunModelForCrowdSoucing());
		
		Method distance = null;
		try {
			distance = SimplexGAforCrowdSourcing.class.getDeclaredMethod("distance", new Class[]{Individual.class, int.class});
			distance.setAccessible(true);
		} catch (SecurityException e) {
			e.printStackTrace();
		} catch (NoSuchMethodException e) {
			e.printStackTrace();
		}

		try {
			double[] result = (double[]) distance.invoke(GAObject, chromosome, 1);
			StringBuilder stringBuilder = new StringBuilder();
			for (int i = 0; i < result.length; ++i)
				stringBuilder.append(result[i]).append("	");
			for (int i = 0; i < chromosome.getLength(); ++i)
				stringBuilder.append(chromosome.get(i)).append("	");
			FileHelper.writeFile("batchRunResult.txt", stringBuilder.toString());
		} catch (IllegalArgumentException e) {
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			e.printStackTrace();
		}
	}
	
	private void SensitivityAnalysisMT()
	{
		double[] metrics = new RunSimulationModelAMT().getTargetMetrics();
		SimplexGAforCrowdSourcing GAObject = new SimplexGAforCrowdSourcing(100, 1, 10, metrics, new RunModelForCrowdSoucing());
		
		Method distance = null;
		try {
			distance = GeneticAlgorithm.class.getDeclaredMethod("fitnessArray", new Class[]{Chromosomes.class, Vector.class});
			distance.setAccessible(true);
		} catch (SecurityException e) {
			e.printStackTrace();
		} catch (NoSuchMethodException e) {
			e.printStackTrace();
		}
		
		String acceptingTimeString = "-4.777,0.83098;0.05362,-0.0006073;0.09645,0.06624;-0.05985,-0.10327;-0.07155,0.18001;-0.0008997,-0.00529;0.02643,-0.06489;0.02531,0.00508;-0.03589,0.02342;7.180,1.139";
		String[] acceptingTimeParams = acceptingTimeString.split(",|;");
		Individual chromosome = new Individual(acceptingTimeParams.length);
		for (int i = 0; i < acceptingTimeParams.length; ++i) {
			if (i < acceptingTimeParams.length)
				chromosome.set(i, Double.parseDouble(acceptingTimeParams[i]));
//			else
//				chromosome.set(i, Double.parseDouble(acceptingTimeParams[(i-acceptingTimeParams.length/2)*2+1]));
		}
		Vector<Individual> individuals = new Vector<Individual>();
		for (int i = 0; i < 4; i++)
			individuals.add(chromosome.clone());
		Chromosomes population = new Chromosomes(individuals);

		try {
			Vector<double[]> metricsVec = new Vector<double[]>();
			for (int i = 0; i < population.getSize(); i++)
				metricsVec.add(null);
			Vector<Double>  result = (Vector<Double>) distance.invoke(GAObject, population, metricsVec);
			for (int i = 0; i < result.size(); ++i)
				System.out.println(result.get(i));
			for (double[] metricsEle : metricsVec)
			{
				for (double metric : metricsEle)
					System.out.print(metric + " ");
				System.out.println();
			}
		} catch (IllegalArgumentException e) {
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			e.printStackTrace();
		}
	}
	
	public double[] testMain(HashMap<String, String> parameters)
	{
		double[] result = null;
		String scenorio = "..\\crowdsourcing\\crowdsourcing.rs";
		File file = new File(scenorio); // the scenario dir
		
		TestRunner runner = new TestRunner("..\\crowdsourcing\\batch\\batch_params.xml");

		try
		{
			runner.load(file); // load the repast scenario
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}

//		System.out.println(parameters);
		for (int i = 1; i < 2; i++)
		{
			setParameters(parameters);
			runner.runInitialize(); // initialize the run			

			//RunEnvironment.getInstance().getParameters().setValue("randomSeed", i*2);
//			RunEnvironment.getInstance().getParameters().setValue("stopTime", 10);
			//int j = (int)RunEnvironment.getInstance().getCurrentSchedule().getTickCount();
			//System.out.println(RunEnvironment.getInstance().getCurrentSchedule().getTickCount());
			while (RunEnvironment.getInstance().getCurrentSchedule().getTickCount() <= (Integer)RunEnvironment.getInstance().getParameters().getValue("stopTime")-1)
			{
				runner.step();
			}

			runner.stop(); // execute any actions scheduled at run end
			runner.cleanUpRun();
		}
		//result = analyzeMetrics(JCrowdsourcingBuilder.g_tasks);
		runner.cleanUpBatch(); // run after all runs complete		
		return result;
	}
	
	private double[] analyzeMetrics(Vector<Task> metrics)
	{
		double[] result = new double[metrics.size()];
		for (int i = 0; i < result.length; ++i)
			System.out.println(metrics.get(i).getID()+" "+(metrics.get(i).get_endTime()-metrics.get(i).get_startTime()));
		return result;
	}

	private Vector<String> readInputFile(String filename)
	{
		Vector<String> result = new Vector<String>();
		FileInputStream fstream = null;
		try
		{
			fstream = new FileInputStream(filename);
		}
		catch (FileNotFoundException e1)
		{
			e1.printStackTrace();
		}
		BufferedReader reader = new BufferedReader(new InputStreamReader(fstream));
		String strLine = "";
		try
		{
			while ((strLine=reader.readLine()) != null)
			{
				result.add(strLine);
			}
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}
		return result;
	}
	private void setParameters(HashMap<String, String> parameters)
	{
		Parameters parameter = RunEnvironment.getInstance().getParameters();
		for (Map.Entry<String, String> entry : parameters.entrySet())
		{
			parameter.setValue(entry.getKey(), entry.getValue());
		}
	}
	
	private double[] getTargetMetrics()
	{
		// completion time, Number of Workers, Number of tasks taken by a worker
		//double[] result = {17.01, 22.55, 19.80, 15.06, 15.52, 21.44, 21.80, 54, 51, 58, 59, 52, 59, 59, 36, 36, 38, 34, 43, 32, 37};
		double[] result = {6085.344828, 26176.66667, 5726.5, 128353.4667, 122704.1333, 10135, 7645.233333, 2147.466667, 6907.433333, 46460.7, 1969.3, 1007.666667, 2182.583333, 3501.28, 508, 13560.24, 4639, 830.4, 5664.666667, 15974.12, 1398.36, 911.2, 306.625, 945.92, 445.48, 2269.8, 986.56, 235.28,
				/*1099, 631.8666667, 859.5, 718.6, 1106.8, 1674, 1327.8, 895.9666667, 1272.933333, 29074.86667, 1266.9, 1210.5, 673.4583333, 1039.92, 360.3333333, 427.32, 889.8, 17304.68, 406.2222222, 474.6, 1308.84, 7531.04, 3657.166667, 1249.44, 7828.8, 1920.6, 702.72, 5390.84, 
				0.824551517, 0.866418667, 0.717071667, 0.939444067, 0.941407933, 0.964014, 0.9217925, 0.9179422, 0.940321567, 0.8610065, 0.839464167, 0.97268425,
				0.811633147, 0.841592529, 0.999259259, 0.927322425, 0.696224971, 0.992623915, 0.884721026, 0.862884622, 0.926709291, 0.971360491, 0.923808791, 0.954084688, 0.923797935, 0.905436467, 0.972899384, 0.946528198*/};
		for (int i = 0; i < result.length; ++i)
		{
//			if (i < result.length*2/3)
//				result[i] = result[i]/60;
//			else
				result[i] = result[i]*10000;
		}
			
		
		//		Vector<String> data = readInputFile("batchCompletionRateDataI.data");
//		double[] completionTimes = new double[data.size()-1];
//		int i = 0;
//		for (String s : data)
//		{
//			String[] values = s.split("	|	|	|	|	");
//
//			double completionTime = 0;
//			try
//			{
//				completionTime = Double.parseDouble(values[4]);			
//			}
//			catch(NumberFormatException e)
//			{
//				continue;
//			}
//			completionTimes[i++] = completionTime;
//		}
//		
//		double[] result = new double[24];
//		for (i = 0; i < completionTimes.length/50; ++i)
//		{
//			if (i >= 24)
//				break;
//			double avg = RunHelper.getInstance().calAvgofIndex(completionTimes, i*50, (i+1)*50);
//			result[i] = (avg);
//		}
		return result;
	}
}
