package algorithm;

import java.util.HashMap;
import java.util.Map;
import java.util.Vector;

import transportation.Pair;
import transportation.RunModelInterface;
import algorithm.Individual;
import algorithm.RunHelper;
import algorithm.SimplexGA;

public class SimplexGAforCrowdSourcing extends SimplexGA
{

	public SimplexGAforCrowdSourcing(int size, int length, int maxRounds, double[] targetMetrics, RunModelInterface runner)
	{
		super(size, length, maxRounds);
		m_runner = runner;
		initTargets(targetMetrics);
	}
	
	@Override
	protected double[] distance(Individual gene, int index)
	{
		double[] result = new double[TargetMetrics.length + 1];
		HashMap<String, Double> metrics = new HashMap<String, Double>();
		
		int replications = 3;
		for (int i = 0; i < replications; ++i)
		{			
			HashMap<String, Double> tmp = m_runner.run(gene, ""+(i+1));
//			metrics.putAll(tmp);
			for (Map.Entry<String, Double> entry : tmp.entrySet())
			{
				Double exited = metrics.get(entry.getKey());
				if (exited == null)
					metrics.put(entry.getKey(), entry.getValue());
				else
					metrics.put(entry.getKey(), entry.getValue()+exited);
			}
		}
		
		for (Map.Entry<String, Double> entry : metrics.entrySet())
		{
			entry.setValue(entry.getValue()/replications);
		}

		if (metrics != null && metrics.size() == TargetMetrics.length)
		{
			for (int i = 0; i < TargetMetrics.length; ++i)
			{
				double simulatedValue = metrics.get(""+TargetMetrics[i][0]);
				result[i + 1] = simulatedValue;
				result[0] += Math.pow((simulatedValue - TargetMetrics[i][1]) / TargetMetrics[i][1], 2);
			}
			result[0] = Math.sqrt(result[0]) / metrics.size();
		}
		else
		{
			result[0] = Double.MAX_VALUE;
		}
		return result;
	}
	
	@Override
	protected void finalOutput(double[] historyicalBestMetrics, Individual historicalBestGene)
	{
		for (int i = 0; i < TargetMetrics.length; ++i)
			m_writer.print(historyicalBestMetrics[i]+" ");
		m_writer.println();
		m_writer.println("Best Parameter is:");
		m_writer.println(historicalBestGene);
	}
	
	@Override
	protected void iterativeOutput(int times, Vector<Double> fitnessArray, int maxIndex, double[] historyicalBestMetrics, Individual historicalBestGene)
	{
		m_writer.println(times+" "+fitnessArray.get(maxIndex)+" "+RunHelper.getInstance().calAvg(fitnessArray.iterator()));
		for (int i = 0; i < TargetMetrics.length; ++i)
			m_writer.print(historyicalBestMetrics[i]+" ");
		m_writer.println();
		m_writer.println(historicalBestGene);
		m_writer.println("-----------------------------------------------------------------------------------");
	}
	
		
	@Override
	protected String initOutputFile() {
		return "outputOptimization.txt";
	}

	protected int[][] targetMetrics()
	{
		return TargetMetrics;
	}
	
	private void initTargets(double[] targetMetrics)
	{
		TargetMetrics = new int[targetMetrics.length][2];
		for (int i = 0; i < targetMetrics.length; ++i)
		{
			TargetMetrics[i][0] = i;
			TargetMetrics[i][1] = (int)targetMetrics[i];
		}
			
	}

	private RunModelInterface m_runner = null;
	private static int indexVar = 0;
	
// accepting time parameters range
//	public static Pair<Integer, Pair<Double, Double>> m_acceptingTimeMu1 = new Pair<Integer, Pair<Double, Double>>(indexVar++, new Pair<Double, Double>(-5.0, -4.0));
//	public static Pair<Integer, Pair<Double, Double>> m_acceptingTimeSigma1 = new Pair<Integer, Pair<Double, Double>>(indexVar++, new Pair<Double, Double>(0.8, 0.9));
//	public static Pair<Integer, Pair<Double, Double>> m_acceptingTimeMu2 = new Pair<Integer, Pair<Double, Double>>(indexVar++, new Pair<Double, Double>(0.05, 0.06));
//	public static Pair<Integer, Pair<Double, Double>> m_acceptingTimeSigma2 = new Pair<Integer, Pair<Double, Double>>(indexVar++, new Pair<Double, Double>(-0.00065, -0.00055));
//	public static Pair<Integer, Pair<Double, Double>> m_acceptingTimeMu3 = new Pair<Integer, Pair<Double, Double>>(indexVar++, new Pair<Double, Double>(0.09, 0.1));
//	public static Pair<Integer, Pair<Double, Double>> m_acceptingTimeSigma3 = new Pair<Integer, Pair<Double, Double>>(indexVar++, new Pair<Double, Double>(0.06, 0.07));
//	public static Pair<Integer, Pair<Double, Double>> m_acceptingTimeMu4 = new Pair<Integer, Pair<Double, Double>>(indexVar++, new Pair<Double, Double>(-0.065, -0.055));
//	public static Pair<Integer, Pair<Double, Double>> m_acceptingTimeSigma4 = new Pair<Integer, Pair<Double, Double>>(indexVar++, new Pair<Double, Double>(-0.15, -0.05));
//	public static Pair<Integer, Pair<Double, Double>> m_acceptingTimeMu5 = new Pair<Integer, Pair<Double, Double>>(indexVar++, new Pair<Double, Double>(-0.08, -0.07));
//	public static Pair<Integer, Pair<Double, Double>> m_acceptingTimeSigma5 = new Pair<Integer, Pair<Double, Double>>(indexVar++, new Pair<Double, Double>(0.1, 0.2));
//	public static Pair<Integer, Pair<Double, Double>> m_acceptingTimeMu6 = new Pair<Integer, Pair<Double, Double>>(indexVar++, new Pair<Double, Double>(-0.00095, -0.00085));
//	public static Pair<Integer, Pair<Double, Double>> m_acceptingTimeSigma6 = new Pair<Integer, Pair<Double, Double>>(indexVar++, new Pair<Double, Double>(-0.006, -0.005));
//	public static Pair<Integer, Pair<Double, Double>> m_acceptingTimeMu7 = new Pair<Integer, Pair<Double, Double>>(indexVar++, new Pair<Double, Double>(0.02, 0.03));
//	public static Pair<Integer, Pair<Double, Double>> m_acceptingTimeSigma7 = new Pair<Integer, Pair<Double, Double>>(indexVar++, new Pair<Double, Double>(-0.07, -0.06));
//	public static Pair<Integer, Pair<Double, Double>> m_acceptingTimeMu8 = new Pair<Integer, Pair<Double, Double>>(indexVar++, new Pair<Double, Double>(0.02, 0.03));
//	public static Pair<Integer, Pair<Double, Double>> m_acceptingTimeSigma8 = new Pair<Integer, Pair<Double, Double>>(indexVar++, new Pair<Double, Double>(0.0045, 0.0055));
//	public static Pair<Integer, Pair<Double, Double>> m_acceptingTimeMu9 = new Pair<Integer, Pair<Double, Double>>(indexVar++, new Pair<Double, Double>(-0.04, -0.03));
//	public static Pair<Integer, Pair<Double, Double>> m_acceptingTimeSigma9 = new Pair<Integer, Pair<Double, Double>>(indexVar++, new Pair<Double, Double>(0.02, 0.03));
//	public static Pair<Integer, Pair<Double, Double>> m_acceptingTimeMu10 = new Pair<Integer, Pair<Double, Double>>(indexVar++, new Pair<Double, Double>(7.0, 8.0));
//	public static Pair<Integer, Pair<Double, Double>> m_acceptingTimeSigma10 = new Pair<Integer, Pair<Double, Double>>(indexVar++, new Pair<Double, Double>(1.0, 2.0));

// working time parameters range	
//	public static Pair<Integer, Pair<Double, Double>> m_acceptingTimeMu1 = new Pair<Integer, Pair<Double, Double>>(indexVar++, new Pair<Double, Double>(1.0, 1.4));
//	public static Pair<Integer, Pair<Double, Double>> m_acceptingTimeSigma1 = new Pair<Integer, Pair<Double, Double>>(indexVar++, new Pair<Double, Double>(0.4, 0.6));
//	public static Pair<Integer, Pair<Double, Double>> m_acceptingTimeMu2 = new Pair<Integer, Pair<Double, Double>>(indexVar++, new Pair<Double, Double>(0.04, 0.06));
//	public static Pair<Integer, Pair<Double, Double>> m_acceptingTimeSigma2 = new Pair<Integer, Pair<Double, Double>>(indexVar++, new Pair<Double, Double>(-0.009, -0.008));
//	public static Pair<Integer, Pair<Double, Double>> m_acceptingTimeMu3 = new Pair<Integer, Pair<Double, Double>>(indexVar++, new Pair<Double, Double>(0.13, 0.15));
//	public static Pair<Integer, Pair<Double, Double>> m_acceptingTimeSigma3 = new Pair<Integer, Pair<Double, Double>>(indexVar++, new Pair<Double, Double>(-0.05, -0.04));
//	public static Pair<Integer, Pair<Double, Double>> m_acceptingTimeMu4 = new Pair<Integer, Pair<Double, Double>>(indexVar++, new Pair<Double, Double>(-0.15, -0.13));
//	public static Pair<Integer, Pair<Double, Double>> m_acceptingTimeSigma4 = new Pair<Integer, Pair<Double, Double>>(indexVar++, new Pair<Double, Double>(-0.16, -0.15));
//	public static Pair<Integer, Pair<Double, Double>> m_acceptingTimeMu5 = new Pair<Integer, Pair<Double, Double>>(indexVar++, new Pair<Double, Double>(-0.3, -0.2));
//	public static Pair<Integer, Pair<Double, Double>> m_acceptingTimeSigma5 = new Pair<Integer, Pair<Double, Double>>(indexVar++, new Pair<Double, Double>(-0.09, -0.07));
//	public static Pair<Integer, Pair<Double, Double>> m_acceptingTimeMu6 = new Pair<Integer, Pair<Double, Double>>(indexVar++, new Pair<Double, Double>(-0.005, -0.003));
//	public static Pair<Integer, Pair<Double, Double>> m_acceptingTimeSigma6 = new Pair<Integer, Pair<Double, Double>>(indexVar++, new Pair<Double, Double>(-0.005, -0.003));
//	public static Pair<Integer, Pair<Double, Double>> m_acceptingTimeMu7 = new Pair<Integer, Pair<Double, Double>>(indexVar++, new Pair<Double, Double>(-0.04, -0.03));
//	public static Pair<Integer, Pair<Double, Double>> m_acceptingTimeSigma7 = new Pair<Integer, Pair<Double, Double>>(indexVar++, new Pair<Double, Double>(-0.04, -0.03));
//	public static Pair<Integer, Pair<Double, Double>> m_acceptingTimeMu8 = new Pair<Integer, Pair<Double, Double>>(indexVar++, new Pair<Double, Double>(0.003, 0.004));
//	public static Pair<Integer, Pair<Double, Double>> m_acceptingTimeSigma8 = new Pair<Integer, Pair<Double, Double>>(indexVar++, new Pair<Double, Double>(0.003, 0.004));
//	public static Pair<Integer, Pair<Double, Double>> m_acceptingTimeMu9 = new Pair<Integer, Pair<Double, Double>>(indexVar++, new Pair<Double, Double>(0.01, 0.03));
//	public static Pair<Integer, Pair<Double, Double>> m_acceptingTimeSigma9 = new Pair<Integer, Pair<Double, Double>>(indexVar++, new Pair<Double, Double>(0.006, 0.007));
//	public static Pair<Integer, Pair<Double, Double>> m_acceptingTimeMu10 = new Pair<Integer, Pair<Double, Double>>(indexVar++, new Pair<Double, Double>(4.0, 6.0));
//	public static Pair<Integer, Pair<Double, Double>> m_acceptingTimeSigma10 = new Pair<Integer, Pair<Double, Double>>(indexVar++, new Pair<Double, Double>(1.0, 2.0));

// accuracy parameters range
	public static Pair<Integer, Pair<Double, Double>> m_acceptingTimeMu1 = new Pair<Integer, Pair<Double, Double>>(indexVar++, new Pair<Double, Double>(-1.7, -1.5));
	public static Pair<Integer, Pair<Double, Double>> m_acceptingTimeSigma1 = new Pair<Integer, Pair<Double, Double>>(indexVar++, new Pair<Double, Double>(0.4, 0.6));
	public static Pair<Integer, Pair<Double, Double>> m_acceptingTimeMu2 = new Pair<Integer, Pair<Double, Double>>(indexVar++, new Pair<Double, Double>(0.03, 0.05));
	public static Pair<Integer, Pair<Double, Double>> m_acceptingTimeSigma2 = new Pair<Integer, Pair<Double, Double>>(indexVar++, new Pair<Double, Double>(-0.1, -0.08));
	public static Pair<Integer, Pair<Double, Double>> m_acceptingTimeMu3 = new Pair<Integer, Pair<Double, Double>>(indexVar++, new Pair<Double, Double>(0.2, 0.4));
	public static Pair<Integer, Pair<Double, Double>> m_acceptingTimeSigma3 = new Pair<Integer, Pair<Double, Double>>(indexVar++, new Pair<Double, Double>(-0.2, -0.01));
	public static Pair<Integer, Pair<Double, Double>> m_acceptingTimeMu4 = new Pair<Integer, Pair<Double, Double>>(indexVar++, new Pair<Double, Double>(0.1, 0.2));
	public static Pair<Integer, Pair<Double, Double>> m_acceptingTimeSigma4 = new Pair<Integer, Pair<Double, Double>>(indexVar++, new Pair<Double, Double>(0.04, 0.07));
	public static Pair<Integer, Pair<Double, Double>> m_acceptingTimeMu5 = new Pair<Integer, Pair<Double, Double>>(indexVar++, new Pair<Double, Double>(-0.6, -0.4));
	public static Pair<Integer, Pair<Double, Double>> m_acceptingTimeSigma5 = new Pair<Integer, Pair<Double, Double>>(indexVar++, new Pair<Double, Double>(0.4, 0.6));
	public static Pair<Integer, Pair<Double, Double>> m_acceptingTimeMu6 = new Pair<Integer, Pair<Double, Double>>(indexVar++, new Pair<Double, Double>(0.002, 0.004));
	public static Pair<Integer, Pair<Double, Double>> m_acceptingTimeSigma6 = new Pair<Integer, Pair<Double, Double>>(indexVar++, new Pair<Double, Double>(-0.02, -0.01));
	public static Pair<Integer, Pair<Double, Double>> m_acceptingTimeMu7 = new Pair<Integer, Pair<Double, Double>>(indexVar++, new Pair<Double, Double>(-0.07, -0.06));
	public static Pair<Integer, Pair<Double, Double>> m_acceptingTimeSigma7 = new Pair<Integer, Pair<Double, Double>>(indexVar++, new Pair<Double, Double>(-0.09, -0.08));
	public static Pair<Integer, Pair<Double, Double>> m_acceptingTimeMu8 = new Pair<Integer, Pair<Double, Double>>(indexVar++, new Pair<Double, Double>(-0.008, -0.007));
	public static Pair<Integer, Pair<Double, Double>> m_acceptingTimeSigma8 = new Pair<Integer, Pair<Double, Double>>(indexVar++, new Pair<Double, Double>(-0.004, -0.003));
	public static Pair<Integer, Pair<Double, Double>> m_acceptingTimeMu9 = new Pair<Integer, Pair<Double, Double>>(indexVar++, new Pair<Double, Double>(0.05, 0.07));
	public static Pair<Integer, Pair<Double, Double>> m_acceptingTimeSigma9 = new Pair<Integer, Pair<Double, Double>>(indexVar++, new Pair<Double, Double>(-0.02, -0.01));
	public static Pair<Integer, Pair<Double, Double>> m_acceptingTimeMu10 = new Pair<Integer, Pair<Double, Double>>(indexVar++, new Pair<Double, Double>(-9.0, -8.0));
	public static Pair<Integer, Pair<Double, Double>> m_acceptingTimeSigma10 = new Pair<Integer, Pair<Double, Double>>(indexVar++, new Pair<Double, Double>(8.0, 10.0));
	
	private int[][] TargetMetrics;
}
