package algorithm;

import java.util.HashMap;
import java.util.Map;
import java.util.Vector;

import transportation.Pair;
import transportation.RunModelInterface;
import algorithm.Individual;
import algorithm.RunHelper;
import algorithm.SimplexGA;

public class SimplexGAforCrowdSourcingOptimization extends SimplexGA
{

	public SimplexGAforCrowdSourcingOptimization(int size, int length, int maxRounds, double[] targetMetrics, RunModelInterface runner)
	{
		super(size, length, maxRounds);
		m_runner = runner;
		initTargets(targetMetrics);
	}
	
	@Override
	protected double[] distance(Individual gene, int index)
	{
		double[] result = new double[TargetMetrics.length + 1];
		HashMap<String, Double> metrics = new HashMap<String, Double>();
		
		int replications = 3;
		for (int i = 0; i < replications; ++i)
		{			
			HashMap<String, Double> tmp = m_runner.run(gene, ""+(i+1));
//			metrics.putAll(tmp);
			for (Map.Entry<String, Double> entry : tmp.entrySet())
			{
				Double exited = metrics.get(entry.getKey());
				if (exited == null)
					metrics.put(entry.getKey(), entry.getValue());
				else
					metrics.put(entry.getKey(), entry.getValue()+exited);
			}
		}
		
		for (Map.Entry<String, Double> entry : metrics.entrySet())
		{
			entry.setValue(entry.getValue()/replications);
		}

		if (metrics != null && metrics.size() == TargetMetrics.length)
		{
			for (int i = 0; i < TargetMetrics.length; ++i)
			{
				double simulatedValue = metrics.get(""+TargetMetrics[i][0]);
				result[i + 1] = simulatedValue;
				result[0] += Math.pow((simulatedValue - TargetMetrics[i][1]) / TargetMetrics[i][1], 2);
			}
			result[0] = Math.sqrt(result[0]) / metrics.size();
		}
		else
		{
			result[0] = Double.MAX_VALUE;
		}
		return result;
	}
	
	@Override
	protected void finalOutput(double[] historyicalBestMetrics, Individual historicalBestGene)
	{
		for (int i = 0; i < TargetMetrics.length; ++i)
			m_writer.print(historyicalBestMetrics[i]+" ");
		m_writer.println();
		m_writer.println("Best Parameter is:");
		m_writer.println(historicalBestGene);
	}
	
	@Override
	protected void iterativeOutput(int times, Vector<Double> fitnessArray, int maxIndex, double[] historyicalBestMetrics, Individual historicalBestGene)
	{
		m_writer.println(times+" "+fitnessArray.get(maxIndex)+" "+RunHelper.getInstance().calAvg(fitnessArray.iterator()));
		for (int i = 0; i < TargetMetrics.length; ++i)
			m_writer.print(historyicalBestMetrics[i]+" ");
		m_writer.println();
		m_writer.println(historicalBestGene);
		m_writer.println("-----------------------------------------------------------------------------------");
	}
	
		
	@Override
	protected String initOutputFile() {
		return "outputOptimization.txt";
	}

	protected int[][] targetMetrics()
	{
		return TargetMetrics;
	}
	
	private void initTargets(double[] targetMetrics)
	{
		TargetMetrics = new int[targetMetrics.length][2];
		for (int i = 0; i < targetMetrics.length; ++i)
		{
			TargetMetrics[i][0] = i;
			TargetMetrics[i][1] = (int)targetMetrics[i];
		}
			
	}

	private RunModelInterface m_runner = null;
	private static int indexVar = 0;
	
	// accuracy parameters range
	public static Pair<Integer, Pair<Double, Double>> m_Incentive = new Pair<Integer, Pair<Double, Double>>(indexVar++, new Pair<Double, Double>(0.0, 2.0));
	public static Pair<Integer, Pair<Integer, Integer>> m_VideoSpeed = new Pair<Integer, Pair<Integer, Integer>>(indexVar++, new Pair<Integer, Integer>(8, 64));
	public static Pair<Integer, Pair<Integer, Integer>> m_VideoDuration = new Pair<Integer, Pair<Integer, Integer>>(indexVar++, new Pair<Integer, Integer>(1, 10));
	public static Pair<Integer, int[]> m_Weekday = new Pair<Integer, int[]>(indexVar++, new int[]{-1, 1});
	public static Pair<Integer, int[]> m_Country = new Pair<Integer, int[]>(indexVar++, new int[]{-1, 1});
	public static Pair<Integer, Pair<Integer, Integer>> m_ApprovalRate = new Pair<Integer, Pair<Integer, Integer>>(indexVar++, new Pair<Integer, Integer>(0, 100));
	public static Pair<Integer, Pair<Integer, Integer>> m_TimeofDay = new Pair<Integer, Pair<Integer, Integer>>(indexVar++, new Pair<Integer, Integer>(1, 24));
	public static Pair<Integer, Pair<Integer, Integer>> m_LifeTime = new Pair<Integer, Pair<Integer, Integer>>(indexVar++, new Pair<Integer, Integer>(1, 72));
	public static Pair<Integer, Pair<Integer, Integer>> m_AssignmentDuration = new Pair<Integer, Pair<Integer, Integer>>(indexVar++, new Pair<Integer, Integer>(1, 24));
	
	private int[][] TargetMetrics;
}
