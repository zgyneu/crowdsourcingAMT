package algorithm;

import java.io.File;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.TreeMap;
import java.util.Vector;

import crowdsourcing.Agent;
import crowdsourcing.JCrowdsourcingBuilder;
import crowdsourcing.Task;
import data.DataStore;
import RunCrowdsourcing.TestRunner;
import algorithm.Individual;
import repast.simphony.engine.environment.RunEnvironment;
import repast.simphony.parameter.Parameters;
import repast.simphony.random.RandomHelper;
import transportation.RunModelInterface;

public class RunModelForCrowdSoucing implements RunModelInterface
{

	@Override
	public HashMap<String, Double> run(Individual gene, String modelDirectory)
	{
		String parametersToTune = "acceptingTimeRegression";
		HashMap<String, String> parameters = new HashMap<String, String>();
		if (gene != null)
		{
			StringBuilder acceptingTimeRegressionParam = new StringBuilder();
			for (int i = 0; i < gene.getLength(); ++i)
			{
				acceptingTimeRegressionParam.append(gene.get(i));
				if (i % 2 == 0)
					acceptingTimeRegressionParam.append(",");
				else
					acceptingTimeRegressionParam.append(";");
			}
//			parameters.put("acceptingTimeRegression", acceptingTimeRegressionParam.toString());
			parameters.put(parametersToTune, acceptingTimeRegressionParam.toString());
		}
//		parameters.put("serviceTimeUS", ""+(int)gene.get(0));
//		parameters.put("serviceTimePH", ""+(int)gene.get(1));
//		parameters.put("serviceTimeIN", ""+(int)gene.get(2));
//		parameters.put("serviceTimeOther", ""+(int)gene.get(3));
//		parameters.put("tasksPerWorkerUS_P3", ""+gene.get(4));
//		parameters.put("tasksPerWorkerPH_P3", ""+gene.get(5));
//		parameters.put("tasksPerWorkerIN_P3", ""+gene.get(6));
//		parameters.put("tasksPerWorkerOther_P3", ""+gene.get(7));
//		parameters.put("tasksPerWorkerUS_P1", ""+gene.get(4));
//		parameters.put("tasksPerWorkerUS_P2", ""+gene.get(5));
//		parameters.put("tasksPerWorkerPH_P1", ""+gene.get(6));
//		parameters.put("tasksPerWorkerPH_P2", ""+gene.get(7));
//		parameters.put("tasksPerWorkerIN_P1", ""+gene.get(8));
//		parameters.put("tasksPerWorkerIN_P2", ""+gene.get(9));
//		parameters.put("tasksPerWorkerOther_P1", ""+gene.get(10));
//		parameters.put("tasksPerWorkerOther_P2", ""+gene.get(11));
//		if (gene != null)
//			parameters.put("showupPowerLawCoefficient", ""+gene.get(0));
		parameters.put("randomSeed", ""+Integer.parseInt(modelDirectory));
		HashMap<String, Double> result = new HashMap<String, Double>();
		String scenorio = "..\\crowdsourcingAMT\\crowdsourcing.rs";
		File file = new File(scenorio); // the scenario dir
		
		TestRunner runner = new TestRunner("..\\crowdsourcingAMT\\batch\\batch_params.xml");

		try
		{
			runner.load(file); // load the repast scenario
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}

		// Run the sim a few times to check for cleanup and init issues.
//		JCrowdsourcingBuilder.g_tasks.clear();

//		System.out.println(parameters);
		for (int i = 1; i < 2; i++)
		{
			setParameters(parameters);
			runner.runInitialize(); // initialize the run			

			//RunEnvironment.getInstance().getParameters().setValue("randomSeed", i*2);
//			RunEnvironment.getInstance().getParameters().setValue("stopTime", 10);
			//int j = (int)RunEnvironment.getInstance().getCurrentSchedule().getTickCount();
			//System.out.println(RunEnvironment.getInstance().getCurrentSchedule().getTickCount());
			while (RunEnvironment.getInstance().getCurrentSchedule().getTickCount() <= (Integer)RunEnvironment.getInstance().getParameters().getValue("stopTime")-1)
			{
				runner.step();
			}

			runner.stop(); // execute any actions scheduled at run end
			runner.cleanUpRun();
		}
		result = parseOutputMetrics(parametersToTune);
//		result = analyzeMetrics(JCrowdsourcingBuilder.g_tasks, JCrowdsourcingBuilder.g_numberOfWorkers, JCrowdsourcingBuilder.g_numberOfTasksPerWorker);
		runner.cleanUpBatch(); // run after all runs complete		
		return result;
	}
	
	private HashMap<String, Double> parseOutputMetrics(String parameterToTune)
	{
		HashMap<String, Double> result = new HashMap<String, Double>();
		
		Vector<Task> metrics = DataStore.getInstance().g_tasks;
		double sumWorkingTime = 0;
		double sumAcceptingTime = 0;
		double sumAccuracy = 0;
		int num = 0;
		Parameters parameter = RunEnvironment.getInstance().getParameters();
		int num_task = (Integer)parameter.getValue("num_tasks");
		String taskParams = (String)parameter.getValue("taskParams");
		int num_batch = taskParams.split(";").length;
		for (int i = 0; i < metrics.size(); ++i)
		{
			if (metrics.get(i).get_endTime() != Integer.MAX_VALUE)
			{
				sumWorkingTime += metrics.get(i).get_endTime() - metrics.get(i).get_startTime();
				sumAcceptingTime += metrics.get(i).get_startTime() - metrics.get(i).getPostTime();
				sumAccuracy += metrics.get(i).getAccuracy();
				++num;					
			}			
			
			if ((i+1)%(num_task) == 0)
			{
				double acceptingTime = num == 0 ? Double.MAX_VALUE : sumAcceptingTime/num;
				double workingTime = num == 0 ? Double.MAX_VALUE : sumWorkingTime/num;
				double accuracy = num == 0 ? Double.MAX_VALUE : sumAccuracy/num*10000;
//				result.put(""+(i/num_task), acceptingTime);
//				result.put(""+(i/num_task+num_batch), workingTime);
//				result.put(""+(i/num_task+2*num_batch), accuracy);
				
				if (parameterToTune.equals("workingTimeRegression"))
					result.put(""+(i/num_task), workingTime);
				else if (parameterToTune.equals("acceptingTimeRegression"))
					result.put(""+(i/num_task), acceptingTime);
				else if (parameterToTune.equals("accuracyRegression"))
					result.put(""+(i/num_task), accuracy);
				else
					System.out.println("Error in parametersToBeTuned");
				
//				System.out.print("AcceptingTime: "+sumAcceptingTime/num+" "+"WorkingTime: "+sumWorkingTime/num+" "+"Accuracy: "+sumAccuracy/num+" "+"AcceptanceRate: "+(double)num/num_task+" ");
//				System.out.print("AcceptingTime: "+acceptingTime+" ");
				sumWorkingTime = 0;
				sumAcceptingTime = 0;
				sumAccuracy = 0;
				num = 0;
			}
		}
//		System.out.println();
		return result;
	}
	
	private HashMap<String, Double> analyzeMetrics(Vector<Task> metrics, 
			TreeMap<Integer, HashSet<Agent>> numberOfWorkers,
			TreeMap<Integer, HashMap<Agent,Integer>> numberOfTasksPerWorker
			)
	{
		Parameters parameter = RunEnvironment.getInstance().getParameters();
		int num_task = (Integer)parameter.getValue("num_tasks");
		int stop_time = (Integer)parameter.getValue("stopTime");
		int call_frequency = (Integer)parameter.getValue("callFrequecy");
		double sum = 0;
		int num = 0;
		HashMap<String, Double> result = new HashMap<String, Double>();
		int i = 0;
		for (; i < metrics.size(); ++i)
		{
			if (metrics.get(i).get_endTime() != Integer.MAX_VALUE)
			{
				sum += metrics.get(i).get_endTime() - metrics.get(i).get_startTime();
				++num;
				
			}
			
			if ((i+1)%(num_task*24*JCrowdsourcingBuilder.g_timeIntervalToAnalyze) == 0)
			{
				result.put(""+(i/(num_task*24*JCrowdsourcingBuilder.g_timeIntervalToAnalyze)), sum/num);
				sum = 0;
				num = 0;
			}
		}
		
		int lastIndex = stop_time/call_frequency;
		result.remove(""+lastIndex);
	
		i = result.size();
		num = 1;
		sum = 0;
		for (Map.Entry<Integer, HashSet<Agent>> entry : numberOfWorkers.entrySet())
		{
			sum += entry.getValue().size();
			if (num % JCrowdsourcingBuilder.g_timeIntervalToAnalyze == 0)
			{
				result.put(""+i, sum/num);
				i++;
				sum = 0;
				num = 1;
			}
			else
				num++;
		}
		
		sum = 0;
		num = 1;
		int workers = 0;
		for (Map.Entry<Integer, HashMap<Agent,Integer>> entry : numberOfTasksPerWorker.entrySet())
		{
			for (Map.Entry<Agent,Integer> entry2 : entry.getValue().entrySet())
			{
				sum += entry2.getValue();
				workers++;
			}
			if (num % JCrowdsourcingBuilder.g_timeIntervalToAnalyze == 0)
			{
				result.put(""+i, sum/workers);
				i++;
				sum = 0;
				num = 1;
			}
			else
				num++;
		}
		
		
		
		return result;
	}
	
	private void setParameters(HashMap<String, String> parameters)
	{
		Parameters parameter = RunEnvironment.getInstance().getParameters();
		for (Map.Entry<String, String> entry : parameters.entrySet())
		{
			parameter.setValue(entry.getKey(), entry.getValue());
		}
	}

}
